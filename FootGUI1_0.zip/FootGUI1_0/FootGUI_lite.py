# %% Import the Python

import os
os.environ["QT_API"] = "PySide6"

import matplotlib
matplotlib.use("qtagg")

#from matplotlib.backends.qt_compat import QT_API
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
import pandas as pd
import numpy as np
import ast
#from scipy.spatial import ConvexHull
#from scipy.spatial import Voronoi, voronoi_plot_2d 
from shapely.geometry import Polygon
import os 
import time
from mplsoccer import Pitch
import json
import traceback

import imageio.v2 as imageio
import cv2 #pip install opencv-python
import shutil
import sys
from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QDoubleSpinBox, QGraphicsView,
    QGridLayout, QHBoxLayout, QLabel, QLineEdit, QDialog,
    QMainWindow, QPushButton, QSizePolicy, QSlider,
    QSpacerItem, QSpinBox, QStatusBar, QTabWidget,
    QTextEdit, QVBoxLayout, QWidget)
from PySide6.QtGui import QShortcut, QKeySequence

#User created functions
from Football_backend006 import (meta_extract, 
    roster_extract, track_extract,rect_calcs,convex_calcs,find_gk, find_cent,
    voronoi_calc,scatter,ball_z,plot_distance_and_speed, plot_rectangles,
    plot_centroids, plot_convex_hulls, plot_voronoi,plot_distances,
    plot_team_centroids,plot_dots)


#Dots should deactivate the time variant stuff

class Ui_MainWindow(object):
    def load_data(self):
        try:
            start_time = time.time()
            
            self.pitch_dim = Polygon([(-52.5, -34),( 52.5, -34),( 52.5,  34),(-52.5,  34)])
            
            cwd = os.getcwd()
            game_id = self.game_id.value()
            frames= self.frames_inp.value()
            
            #File location

            data_loc=cwd+"\\Tracking Data\\"+str(game_id)+".jsonl\\"+str(game_id)+".jsonl"
            self.raw = pd.read_json(data_loc,lines=True,nrows=frames)
            self.raw = self.raw[
                self.raw["homePlayersSmoothed"].apply(
                    lambda x: isinstance(x, list) and len(x) == 11
                )
            ]
                
            self.raw = self.raw[
                self.raw["awayPlayersSmoothed"].apply(
                    lambda x: isinstance(x, list) and len(x) == 11
                )
            ]
                
            self.raw = self.raw.reset_index(drop=True)
            frames=self.raw.shape[0]
                
            roster_loc=cwd+"\\Rosters\\"+str(game_id)+".json"
            meta_loc=cwd+"\\Metadata\\"+str(game_id)+".json"
            
            #For Use with the event log
            self.raw_data_loc=data_loc
            #Ensure int
            frames=int(frames)
            self.frames=frames
            # %% Data Imported 
            #This section uses user-defined functions for clarity
            
            #Import the meta data
            [self.away_team,self.away_kit,self.away_data,self.home_team,self.home_kit,
             self.home_data]=meta_extract(meta_loc)
            #Import the roster_data
            (self.home_roster,self.away_roster)=roster_extract(roster_loc,self.home_data,self.away_data)
            #Import the tracking data

            (self.home_track_X,self.home_track_Y,self.home_track_dist,self.home_track_dist_cum,self.home_track_jersey,
             self.home_track_name,self.home_track_speed,self.away_track_X,self.away_track_Y,self.away_track_dist,self.away_track_dist_cum,
             self.away_track_jersey,self.away_track_name,self.away_track_speed,self.ball_track_X,self.ball_track_Y,
             self.ball_track_Z,self.ball_track_dist,self.ball_track_dist_cum,self.ball_track_speed,
            self.game_time,self.avg_diff)=track_extract(data_loc,frames,self.home_roster,self.away_roster,self.raw)
            for i in range(frames):

                if len(self.home_track_X[i]) != 11:
                    print("Bad home frame", i)
            
                if len(self.away_track_X[i]) != 11:
                    print("Bad away frame", i)
            self.data_loaded = True
            self.horizontalSlider.setMaximum(len(self.game_time)-1)
            

        
            
            print("Data Imported --- %s seconds ---" % (time.time() - start_time))
            
            self.process_data()
        except Exception as e:

            print("Loading Error:")
            print(e)
                
                
            # %% Position Idenitfication
    def process_data(self):
        try:
            start_time = time.time()
            frames= self.frames
            self.f_skip= self.frame_skip.value()
            sf_max=10*20
            sf_min=3*20


            self.events = pd.DataFrame(
                columns=["Start Frame", "End Frame", "Team", "Event Name","File Name"]
            )
            self.events_last = pd.DataFrame(
                columns=["Start Frame", "End Frame", "Team", "Event Name","File Name"]
            )
            self.event_flag=1


            #Perfomrs the calulcations to enable the ball to change size                                
            self.sf=ball_z(sf_max,sf_min,self.ball_track_Z)


            if self.timer is None:
                from PySide6.QtCore import QTimer
            
                self.timer = QTimer()
                self.timer.timeout.connect(self.next_frame)

            self.current_frame = 0
            print("Data Processed --- %s seconds ---" % (time.time() - start_time))
            self.tabWidget.setCurrentIndex(1)
        except Exception as e:

            print("="*50)
            print("ERROR TYPE:")
            print(type(e))
            print("="*50)
        
            print("ERROR VALUE:")
            print(e)
            print("="*50)
        
            traceback.print_exc()
            
        self.plot_frame(0)     
        
    def plot_frame(self, i):
        
        
        start_time = time.time()
        fs=5
        ss=20
        ld=1.2*np.sqrt(ss)/3.14 

        #Config Inputs
        bool_generic_colours=self.check_generic_colours.isChecked()
        bool_axis_label=self.check_axis_labels.isChecked()
        bool_flip_ends=self.check_flip_ends.isChecked()
        bool_player_name=self.check_player_name.isChecked()
        bool_player_surname_only=self.check_player_surname_only.isChecked()
        bool_ball=self.check_ball.isChecked()
        frames= self.frames

            

        contrast_colours=ast.literal_eval(self.contrast_colours.toPlainText())
        
        #fs=self.fs.value()
        #ss=self.ss.value()
        #lw=self.lw.value()

        #cs_sf=self.cs_sf.value()

        
        frames=int(frames)
        
        
            
        #Create the translation matrix to flip
        if bool_flip_ends:
            t=-1
        else:
            t=1


        if bool_generic_colours:
            player_colours=contrast_colours
        else:
            player_colours=[self.home_data.iloc[0,2],self.home_data.iloc[0,3],self.away_data.iloc[0,2],self.away_data.iloc[0,3]]
            
        
        self.figure.clear()
        
        ax = self.figure.add_subplot(111)
        
        pitch = Pitch( pitch_type='skillcorner',pitch_length=105, pitch_width=68)

        pitch.draw(ax=ax)

        # pitch = Pitch(pitch_type='skillcorner', pitch_length=105, pitch_width=68,label=bool_axis_label,corner_arcs=True)
        # fig, ax = pitch.draw()



        scatter(ax,pitch,t,ss,ld,fs,self.sf[i],player_colours,self.home_track_X[i,:],self.home_track_Y[i,:],
            self.home_track_name[i,:],self.away_track_X[i,:],self.away_track_Y[i,:],self.away_track_name[i,:],self.ball_track_X[i,:],
            self.ball_track_Y[i,:],bool_player_surname_only,bool_player_name,
            False,bool_ball)



        ax.set_title(self.home_data.iloc[0,0]+" vs "+self.away_data.iloc[0,0])
        ax.set_xlabel('X Position (m)')
        ax.set_ylabel('Y Position (m)')
        ax.set_xlim(pitch.dim.left, pitch.dim.right)
        ax.set_ylim(pitch.dim.bottom, pitch.dim.top)
        self.canvas.draw()     
        
        self.FrameInput.setText(str(i))
        self.TimeInput.setText(str(round(self.game_time[i],5)))
            


    def next_frame(self):
    
        self.current_frame += int(1+self.f_skip)
    
        if self.current_frame >= len(self.game_time):
    
            self.timer.stop()
            self.Play.setText("Play")
            self.current_frame = len(self.game_time) - 1
            return
    
        self.horizontalSlider.setValue(self.current_frame)
        
    def toggle_play(self):
    
        if not self.data_loaded:
            return
    
        if self.timer.isActive():
    
            self.timer.stop()
            self.Play.setText("Play")
    
        else:
    
            interval = int(1000 * self.avg_diff)
            self.timer.start(interval)
            self.Play.setText("Pause")
    def slider_changed(self, value):

        self.current_frame = value
        self.plot_frame(value)
        
    def jump_back_15s(self):
    
        if not self.data_loaded:
            return
        target_time = self.game_time[self.current_frame] - 15
    
        # Cap at minimum
        if target_time < self.game_time[0]:
            target_time = self.game_time[0]
    
        new_frame = np.argmin(np.abs(self.game_time - target_time))
    
        self.current_frame = new_frame
        self.horizontalSlider.setValue(new_frame)
    
    
    def jump_forward_15s(self):
    
        if not self.data_loaded:
            return
    
        target_time = self.game_time[self.current_frame] + 15
    
        # Cap at maximum
        
        if target_time > self.game_time.iloc[-1]:
            target_time = self.game_time.iloc[-1]
    
        new_frame = np.argmin(np.abs(self.game_time - target_time))
    
        self.current_frame = new_frame
        self.horizontalSlider.setValue(new_frame)
        
            
    def assign_start_frame(self):
        self.start_frame.setText(str(self.current_frame))
        #self.first_frame.setValue(self.current_frame)

    def assign_end_frame(self):
        self.end_frame.setText(str(self.current_frame))
        #self.last_frame.setValue(self.current_frame)

    def rec_tab_data(self):
        
        os.makedirs("User Defined Events", exist_ok=True)
        os.makedirs("User Defined Events\\"+str(self.game_id.value()), exist_ok=True)

        frame1=self.start_frame.text()
        frame2=self.end_frame.text()
        event_name=self.event_commit_name.text()

        # Keep rows from frame1 to frame2 inclusive
        raw_subset = self.raw.iloc[int(frame1):int(frame2) + 1]
        
        file_name="User Defined Events\\"+str(self.game_id.value())+"\\"+str(self.game_id.value())+event_name
        
        #if os.path.exists(file_name+"_"+str(self.event_flag)+".jsonl"):
        #    print("Automatically Indexing Upwards")
        #    self.event_flag+=1
        #    file_name+="_"+str(self.event_flag)
        #else:
        #    file_name+="_"+str(self.event_flag)
        #    
        
        flag = 1

        while os.path.exists(f"{file_name}_{flag}.jsonl"):
            flag += 1

        file_name = f"{file_name}_{flag}"
        
        # Save to new JSON file
        raw_subset.to_json(file_name+".jsonl", orient="records",lines=True)

        if self.check_home_event.isChecked():
            team="home"
        else: 
            team="away"

        
        self.events.loc[len(self.events)] = [frame1, frame2, team,event_name,file_name]
        
        print(self.events)

        self.events_last.loc[0]=[frame1, frame2, team,event_name,file_name]

        filename="User Defined Events\\"+str(self.game_id.value())+"\\"+str(self.game_id.value())+"User_Defined_Events.csv"
        self.events_last.to_csv(filename, index=False,mode='a', header=not os.path.exists(filename))
        
    def update_frames(self):
        if self.check_load_all.isChecked():
            self.frames_inp.setValue(self.n_frames)
        else:
            self.frames_inp.setValue(100)    

    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(975, 699)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.gridLayout = QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        self.load = QWidget()
        self.load.setObjectName(u"load")
        self.horizontalLayout_4 = QHBoxLayout(self.load)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.label_48 = QLabel(self.load)
        self.label_48.setObjectName(u"label_48")
        font = QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setUnderline(True)
        self.label_48.setFont(font)
        self.label_48.setAlignment(Qt.AlignCenter)

        self.verticalLayout_3.addWidget(self.label_48)

        self.label_49 = QLabel(self.load)
        self.label_49.setObjectName(u"label_49")
        self.label_49.setAlignment(Qt.AlignCenter)

        self.verticalLayout_3.addWidget(self.label_49)


        self.verticalLayout_5.addLayout(self.verticalLayout_3)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.label_52 = QLabel(self.load)
        self.label_52.setObjectName(u"label_52")
        font1 = QFont()
        font1.setPointSize(10)
        font1.setBold(True)
        font1.setUnderline(True)
        self.label_52.setFont(font1)
        self.label_52.setAlignment(Qt.AlignCenter)

        self.verticalLayout.addWidget(self.label_52)

        self.horizontalLayout_15 = QHBoxLayout()
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.label_23 = QLabel(self.load)
        self.label_23.setObjectName(u"label_23")

        self.horizontalLayout_15.addWidget(self.label_23)

        self.game_id = QSpinBox(self.load)
        self.game_id.setObjectName(u"game_id")
        self.game_id.setMaximum(100000)
        self.game_id.setValue(10513)

        self.horizontalLayout_15.addWidget(self.game_id)


        self.verticalLayout.addLayout(self.horizontalLayout_15)

        self.check_load_all = QCheckBox(self.load)
        self.check_load_all.setObjectName(u"check_load_all")

        self.verticalLayout.addWidget(self.check_load_all)

        self.horizontalLayout_16 = QHBoxLayout()
        self.horizontalLayout_16.setObjectName(u"horizontalLayout_16")
        self.label_24 = QLabel(self.load)
        self.label_24.setObjectName(u"label_24")

        self.horizontalLayout_16.addWidget(self.label_24)

        self.frames_inp = QSpinBox(self.load)
        self.frames_inp.setObjectName(u"frames_inp")
        self.frames_inp.setMaximum(1000000)
        self.frames_inp.setValue(100)

        self.horizontalLayout_16.addWidget(self.frames_inp)


        self.verticalLayout.addLayout(self.horizontalLayout_16)

        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.label_41 = QLabel(self.load)
        self.label_41.setObjectName(u"label_41")
        self.label_41.setFont(font1)
        self.label_41.setAlignment(Qt.AlignCenter)

        self.verticalLayout_6.addWidget(self.label_41)

        self.contrast_colours = QTextEdit(self.load)
        self.contrast_colours.setObjectName(u"contrast_colours")
        self.contrast_colours.setEnabled(True)
        self.contrast_colours.setMaximumSize(QSize(400, 30))

        self.verticalLayout_6.addWidget(self.contrast_colours)


        self.verticalLayout.addLayout(self.verticalLayout_6)

        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer_2)

        self.btn_load_data = QPushButton(self.load)
        self.btn_load_data.setObjectName(u"btn_load_data")

        self.verticalLayout.addWidget(self.btn_load_data)


        self.horizontalLayout_3.addLayout(self.verticalLayout)

        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.label_3 = QLabel(self.load)
        self.label_3.setObjectName(u"label_3")
        font2 = QFont()
        font2.setPointSize(10)
        font2.setBold(True)
        font2.setUnderline(True)
        font2.setKerning(True)
        self.label_3.setFont(font2)
        self.label_3.setAlignment(Qt.AlignCenter)

        self.verticalLayout_4.addWidget(self.label_3)

        self.check_player_name = QCheckBox(self.load)
        self.check_player_name.setObjectName(u"check_player_name")
        self.check_player_name.setEnabled(True)
        self.check_player_name.setLayoutDirection(Qt.LeftToRight)
        self.check_player_name.setChecked(True)

        self.verticalLayout_4.addWidget(self.check_player_name)

        self.check_player_surname_only = QCheckBox(self.load)
        self.check_player_surname_only.setObjectName(u"check_player_surname_only")
        self.check_player_surname_only.setLayoutDirection(Qt.LeftToRight)
        self.check_player_surname_only.setChecked(True)

        self.verticalLayout_4.addWidget(self.check_player_surname_only)

        self.check_ball = QCheckBox(self.load)
        self.check_ball.setObjectName(u"check_ball")
        self.check_ball.setLayoutDirection(Qt.LeftToRight)
        self.check_ball.setChecked(True)

        self.verticalLayout_4.addWidget(self.check_ball)

        self.check_z_ball = QCheckBox(self.load)
        self.check_z_ball.setObjectName(u"check_z_ball")
        self.check_z_ball.setLayoutDirection(Qt.LeftToRight)
        self.check_z_ball.setChecked(True)

        self.verticalLayout_4.addWidget(self.check_z_ball)

        self.check_axis_labels = QCheckBox(self.load)
        self.check_axis_labels.setObjectName(u"check_axis_labels")
        self.check_axis_labels.setLayoutDirection(Qt.LeftToRight)

        self.verticalLayout_4.addWidget(self.check_axis_labels)

        self.check_flip_ends = QCheckBox(self.load)
        self.check_flip_ends.setObjectName(u"check_flip_ends")
        self.check_flip_ends.setLayoutDirection(Qt.LeftToRight)

        self.verticalLayout_4.addWidget(self.check_flip_ends)

        self.check_generic_colours = QCheckBox(self.load)
        self.check_generic_colours.setObjectName(u"check_generic_colours")
        self.check_generic_colours.setLayoutDirection(Qt.LeftToRight)

        self.verticalLayout_4.addWidget(self.check_generic_colours)

        self.horizontalLayout_28 = QHBoxLayout()
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.label_47 = QLabel(self.load)
        self.label_47.setObjectName(u"label_47")

        self.horizontalLayout_28.addWidget(self.label_47)

        self.frame_skip = QSpinBox(self.load)
        self.frame_skip.setObjectName(u"frame_skip")
        self.frame_skip.setMinimum(0)
        self.frame_skip.setMaximum(100)
        self.frame_skip.setValue(0)

        self.horizontalLayout_28.addWidget(self.frame_skip)


        self.verticalLayout_4.addLayout(self.horizontalLayout_28)


        self.horizontalLayout_3.addLayout(self.verticalLayout_4)


        self.verticalLayout_5.addLayout(self.horizontalLayout_3)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_5.addItem(self.verticalSpacer)


        self.horizontalLayout_4.addLayout(self.verticalLayout_5)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_3)

        self.tabWidget.addTab(self.load, "")
        self.view = QWidget()
        self.view.setObjectName(u"view")
        self.verticalLayout_2 = QVBoxLayout(self.view)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.figure = Figure()

        self.canvas = FigureCanvasQTAgg(self.figure)
        
        self.horizontalLayout_2.insertWidget(0,self.canvas)

        self.verticalLayout_2.addLayout(self.horizontalLayout_2)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label = QLabel(self.view)
        self.label.setObjectName(u"label")

        self.horizontalLayout.addWidget(self.label)

        self.FrameInput = QLineEdit(self.view)
        self.FrameInput.setObjectName(u"FrameInput")

        self.horizontalLayout.addWidget(self.FrameInput)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer_2)

        self.back15s = QPushButton(self.view)
        self.back15s.setObjectName(u"back15s")

        self.horizontalLayout.addWidget(self.back15s)

        self.Play = QPushButton(self.view)
        self.Play.setObjectName(u"Play")

        self.horizontalLayout.addWidget(self.Play)

        self.forward15s = QPushButton(self.view)
        self.forward15s.setObjectName(u"forward15s")

        self.horizontalLayout.addWidget(self.forward15s)

        self.label_2 = QLabel(self.view)
        self.label_2.setObjectName(u"label_2")

        self.horizontalLayout.addWidget(self.label_2)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.TimeInput = QLineEdit(self.view)
        self.TimeInput.setObjectName(u"TimeInput")

        self.horizontalLayout.addWidget(self.TimeInput)


        self.verticalLayout_2.addLayout(self.horizontalLayout)

        self.horizontalSlider = QSlider(self.view)
        self.horizontalSlider.setObjectName(u"horizontalSlider")
        self.horizontalSlider.setOrientation(Qt.Horizontal)

        self.verticalLayout_2.addWidget(self.horizontalSlider)

        self.horizontalLayout_30 = QHBoxLayout()
        self.horizontalLayout_30.setObjectName(u"horizontalLayout_30")
        self.label_45 = QLabel(self.view)
        self.label_45.setObjectName(u"label_45")

        self.horizontalLayout_30.addWidget(self.label_45)

        self.start_frame = QLineEdit(self.view)
        self.start_frame.setObjectName(u"start_frame")
        self.start_frame.setMaximumSize(QSize(60, 16777215))

        self.horizontalLayout_30.addWidget(self.start_frame)

        self.btn_asf = QPushButton(self.view)
        self.btn_asf.setObjectName(u"btn_asf")

        self.horizontalLayout_30.addWidget(self.btn_asf)

        self.check_home_event = QCheckBox(self.view)
        self.check_home_event.setObjectName(u"check_home_event")

        self.horizontalLayout_30.addWidget(self.check_home_event)

        self.horizontalSpacer_7 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_30.addItem(self.horizontalSpacer_7)

        self.event_commit_name = QLineEdit(self.view)
        self.event_commit_name.setObjectName(u"event_commit_name")
        self.event_commit_name.setMinimumSize(QSize(80, 0))

        self.horizontalLayout_30.addWidget(self.event_commit_name)

        self.horizontalSpacer_6 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_30.addItem(self.horizontalSpacer_6)

        self.label_46 = QLabel(self.view)
        self.label_46.setObjectName(u"label_46")

        self.horizontalLayout_30.addWidget(self.label_46)

        self.end_frame = QLineEdit(self.view)
        self.end_frame.setObjectName(u"end_frame")
        self.end_frame.setMaximumSize(QSize(50, 16777215))

        self.horizontalLayout_30.addWidget(self.end_frame)

        self.btn_aef = QPushButton(self.view)
        self.btn_aef.setObjectName(u"btn_aef")

        self.horizontalLayout_30.addWidget(self.btn_aef)

        self.horizontalSpacer_8 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_30.addItem(self.horizontalSpacer_8)

        self.btn_tab_record = QPushButton(self.view)
        self.btn_tab_record.setObjectName(u"btn_tab_record")

        self.horizontalLayout_30.addWidget(self.btn_tab_record)


        self.verticalLayout_2.addLayout(self.horizontalLayout_30)

        self.tabWidget.addTab(self.view, "")

        self.gridLayout.addWidget(self.tabWidget, 1, 0, 1, 1)

        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        
        #User defined
                
        self.check_load_all.toggled.connect(self.update_frames)

        cwd=os.getcwd()
        game_id = self.game_id.value()

        data_loc=cwd+"\\Tracking Data\\"+str(game_id)+".jsonl\\"+str(game_id)+".jsonl"

        with open(data_loc, "r", encoding="utf-8") as f:
            self.n_frames = sum(1 for _ in f)
        
        self.frames_inp.setMaximum(self.n_frames)
                
        self.btn_tab_record.clicked.connect(self.rec_tab_data)
        self.btn_asf.clicked.connect(self.assign_start_frame)
        self.btn_aef.clicked.connect(self.assign_end_frame)
                
        # Space = Play/Pause
        self.shortcut_play = QShortcut(QKeySequence(Qt.Key_Space), MainWindow)
        self.shortcut_play.activated.connect(self.toggle_play)
        
        # Left Arrow = Back 15s
        self.shortcut_back = QShortcut(QKeySequence(Qt.Key_Left), MainWindow)
        self.shortcut_back.activated.connect(self.jump_back_15s)
        
        # Right Arrow = Forward 15s
        self.shortcut_forward = QShortcut(QKeySequence(Qt.Key_Right), MainWindow)
        self.shortcut_forward.activated.connect(self.jump_forward_15s)
        
        self.shortcut_next = QShortcut(QKeySequence(Qt.Key_Up), MainWindow)
        self.shortcut_next.activated.connect(
            lambda: self.horizontalSlider.setValue(
                min(self.current_frame + 1,
                    self.horizontalSlider.maximum())
            )
        )
        
        self.shortcut_prev = QShortcut(QKeySequence(Qt.Key_Down), MainWindow)
        self.shortcut_prev.activated.connect(
            lambda: self.horizontalSlider.setValue(
                max(self.current_frame - 1, 0)
            )
        )
        

        
        self.timer = None
        self.back15s.clicked.connect(self.jump_back_15s)
        self.forward15s.clicked.connect(self.jump_forward_15s)
        self.horizontalSlider.valueChanged.connect(self.slider_changed)

                
        # Connect button click
        self.btn_load_data.clicked.connect(self.load_data)
        
        # Connect button click
        self.Play.clicked.connect(self.toggle_play)
        # Connect button click
      
        QMetaObject.connectSlotsByName(MainWindow)
        
        self.tabWidget.setCurrentIndex(0)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label_48.setText(QCoreApplication.translate("MainWindow", u"Football Visualiser - Lite Version", None))
        self.label_49.setText(QCoreApplication.translate("MainWindow", u"by Joshua Montgomery, version 1.0", None))
        self.label_52.setText(QCoreApplication.translate("MainWindow", u"Loading Configuration", None))
        self.label_23.setText(QCoreApplication.translate("MainWindow", u"Game ID", None))
        self.check_load_all.setText(QCoreApplication.translate("MainWindow", u"Load All Frames", None))
        self.label_24.setText(QCoreApplication.translate("MainWindow", u"Load Frames", None))
        self.label_41.setText(QCoreApplication.translate("MainWindow", u"Contrast Colours", None))
        self.contrast_colours.setMarkdown(QCoreApplication.translate("MainWindow", u"['#0040ff','#fffefc','#fa0000','#0d0d0d']\n"
"\n"
"", None))
        self.btn_load_data.setText(QCoreApplication.translate("MainWindow", u"Load and Process Data", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"General", None))
        self.check_player_name.setText(QCoreApplication.translate("MainWindow", u"Plot Player Names", None))
        self.check_player_surname_only.setText(QCoreApplication.translate("MainWindow", u"Only Player Surnames", None))
        self.check_ball.setText(QCoreApplication.translate("MainWindow", u"Plot the Ball", None))
        self.check_z_ball.setText(QCoreApplication.translate("MainWindow", u"Plot Ball in Z", None))
        self.check_axis_labels.setText(QCoreApplication.translate("MainWindow", u"Axis Labels", None))
        self.check_flip_ends.setText(QCoreApplication.translate("MainWindow", u"Flip Ends", None))
        self.check_generic_colours.setText(QCoreApplication.translate("MainWindow", u"Generic Colours", None))
        self.label_47.setText(QCoreApplication.translate("MainWindow", u"Frame Skip", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.load), QCoreApplication.translate("MainWindow", u"Load", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Frame:", None))
        self.back15s.setText(QCoreApplication.translate("MainWindow", u"Go Back 15s", None))
        self.Play.setText(QCoreApplication.translate("MainWindow", u"Play", None))
        self.forward15s.setText(QCoreApplication.translate("MainWindow", u"Go Forward 15s", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Time (s):", None))
        self.label_45.setText(QCoreApplication.translate("MainWindow", u"Start Frame:", None))
        self.btn_asf.setText(QCoreApplication.translate("MainWindow", u"Assign Start Frame", None))
        self.check_home_event.setText(QCoreApplication.translate("MainWindow", u"Home Team Event", None))
        self.event_commit_name.setText(QCoreApplication.translate("MainWindow", u"Event Name", None))
        self.label_46.setText(QCoreApplication.translate("MainWindow", u"End Frame:", None))
        self.btn_aef.setText(QCoreApplication.translate("MainWindow", u"Assign End Frame", None))
        self.btn_tab_record.setText(QCoreApplication.translate("MainWindow", u"Commit", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.view), QCoreApplication.translate("MainWindow", u"View", None))
    # retranslateUi


if __name__ == "__main__":

    app = QApplication.instance()

    if app is None:
        app = QApplication(sys.argv)

    MainWindow = QMainWindow()

    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)

    MainWindow.show()

    sys.exit(app.exec())