# This script is to check that all the labelled events have consistent names

#Mac version

import os
import pandas as pd

#Setup
game_id=10513
valid_names = {"HP", "MP", "LP"}

# %% Analyse Existing Data
cwd=os.getcwd()

event_data_loc=cwd+"/User Defined Events/"+str(game_id)+"/"+str(game_id)+"User_Defined_Events.csv"

event_tab = pd.read_csv(event_data_loc)
print(event_tab.head())

event_breakdown = event_tab["Event Name"].value_counts()

print(event_breakdown)

# %% Clean the names
# Make a copy so the original is preserved
event_tab_clean = event_tab.copy()

# Find invalid event names
invalid_names = sorted(
    set(event_tab_clean["Event Name"].dropna().unique()) - valid_names
)

# Store user decisions
corrections = {}

for bad_name in invalid_names:

    while True:
        response = input(
            f"'{bad_name}' is not valid.\n"
            "Enter HP, MP, LP, or D to Delete: "
        ).strip().upper()

        if response in {"HP", "MP", "LP", "D"}:
            corrections[bad_name] = response
            break

        print("Invalid choice. Please enter HP, MP, LP, or D to Delete.")

# Apply corrections
for bad_name, action in corrections.items():

    if action == "D":
        event_tab_clean = event_tab_clean[
            event_tab_clean["Event Name"] != bad_name
        ]
    else:
        event_tab_clean.loc[
            event_tab_clean["Event Name"] == bad_name,
            "Event Name"
        ] = action
        
print("Cleaning complete.")
print(event_tab_clean["Event Name"].value_counts())
        
# %% Clean the Timings

# Rule 1: End Frame must be greater than Start Frame
invalid_duration = event_tab["End Frame"] <= event_tab["Start Frame"]

# Rule 2: Start Frame must be different from the row above
duplicate_start = event_tab["Start Frame"] == event_tab["Start Frame"].shift(1)

# Rule 3: End Frame must be different from the row above
duplicate_end = event_tab["End Frame"] == event_tab["End Frame"].shift(1)

# Combine all validation checks
invalid_rows = invalid_duration | duplicate_start | duplicate_end

# View problematic rows
problems = event_tab.loc[invalid_rows].copy()

print("\nChecking the timings are rational")
print(f"Found {len(problems)} problematic rows")
print(problems)


filename="User Defined Events/"+str(game_id)+"/"+str(game_id)+"User_Defined_Events.csv"
event_tab_clean.to_csv(filename, index=False )