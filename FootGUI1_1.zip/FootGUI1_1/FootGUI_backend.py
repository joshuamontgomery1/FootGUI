#The backend for football analytics code. As much as possible has been removed
#from the GUI script and inserted here. This is to minmise the length of the
#primary script and keeps things orderly

#Version003 (unreleased)
#By Joshua Montgomery (jm26774@essex.ac.uk), all rights reserved


#%% Environmnet 
#Many libraries used in the main script are also needed in here

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import os
from scipy.spatial import ConvexHull
from scipy.spatial import Voronoi, voronoi_plot_2d 
from shapely.geometry import Polygon
# %%
import time
from mplsoccer import Pitch
import imageio.v2 as imageio
import cv2 #pip install opencv-python
import shutil

#%% Functions - Importing data

def meta_extract(meta_loc):
    meta_df=pd.read_json(meta_loc)

    away_team=pd.json_normalize(meta_df["awayTeam"])
    away_kit=pd.json_normalize(meta_df["awayTeamKit"])
    away_data=pd.concat([away_team[['name','shortName']],away_kit[['primaryColor','primaryTextColor']]],axis=1)

    home_team=pd.json_normalize(meta_df["homeTeam"])
    home_kit=pd.json_normalize(meta_df["homeTeamKit"])
    home_data=pd.concat([home_team[['name','shortName']],home_kit[['primaryColor','primaryTextColor']]],axis=1)
    
    return away_team,away_kit,away_data,home_team,home_kit,home_data

def roster_extract(roster_loc,home_data,away_data):
    roster_df=pd.read_json(roster_loc)
    roster_player=pd.DataFrame(roster_df.iloc[:, 0].tolist())
    roster_team=pd.DataFrame(roster_df.iloc[:, 4].tolist())

    roster = pd.concat([roster_player, roster_df[['positionGroupType','shirtNumber']],           # take only this column
            roster_team[['name']]],axis=1)

    #Seperate the rosters based on teams
    home_roster = roster[roster.iloc[:, 4] == home_data.iloc[0,0]]
    away_roster  = roster[roster.iloc[:, 4] == away_data.iloc[0,0]]
    return home_roster,away_roster

def track_extract(data_loc,frames,home_roster,away_roster,raw):
    # Load the first record from the JSONL file
    
    #Initalise the matricies
    home_track_X=np.zeros((frames,11),dtype=float)
    home_track_Y=np.zeros((frames,11),dtype=float)
    home_track_dist=np.zeros((frames,11),dtype=float)
    home_track_speed=np.zeros((frames,11),dtype=float)
    home_track_dist_cum=np.zeros((frames,11),dtype=float)
    home_track_jersey=np.zeros((frames,11),dtype=int)
    
    away_track_X=np.zeros((frames,11),dtype=float)
    away_track_Y=np.zeros((frames,11),dtype=float)
    away_track_dist=np.zeros((frames,11),dtype=float)
    away_track_speed=np.zeros((frames,11),dtype=float)
    away_track_dist_cum=np.zeros((frames,11),dtype=float)
    away_track_jersey=np.zeros((frames,11),dtype=int)
    
    ball_track_X=np.zeros((frames,1),dtype=float)
    ball_track_Y=np.zeros((frames,1),dtype=float)
    ball_track_Z=np.zeros((frames,1),dtype=float)
    ball_track_dist=np.zeros((frames,1),dtype=float)
    ball_track_speed=np.zeros((frames,1),dtype=float)
    ball_track_dist_cum=np.zeros((frames,1),dtype=float)
    
    game_time=raw['periodGameClockTime']
    avg_diff = game_time.diff().mean()
    
    for i in range(frames):
        
        df= raw.iloc[i]
        ## Home Players
        # Create a dataframe with one row per home player per frame    
        # Convert nested player JSON into columns
        player_details = pd.json_normalize(df["homePlayersSmoothed"])
        
        #Sometimes the input data has two sets of data for each player
        player_details = player_details[player_details["jerseyNum"] != player_details["jerseyNum"].shift()]
        
        home_players=player_details[["jerseyNum","x","y"]]
        
        ## Away players
        # Create a dataframe with one row per home player per frame    
        # Convert nested player JSON into columns
        player_details = pd.json_normalize(df["awayPlayersSmoothed"])
        #Sometimes the input data has two sets of data for each player
        player_details = player_details[player_details["jerseyNum"] != player_details["jerseyNum"].shift()]
        
        away_players=player_details[["jerseyNum","x","y"]]
        
        ##Ball
        
        #ballsSmoother appears to be saved improperly, hence we are using balls.
        #The issue may be specifc to this data set    
        ball_details=pd.json_normalize(df["balls"])
        if np.size(ball_details)==0:
            ball_track_X[i,:]=np.nan
            ball_track_Y[i,:]=np.nan
            ball_track_Z[i,:]=np.nan
    
        else:
            ball=ball_details[["x","y","z"]]
            ball_track_X[i,:]=ball['x']
            ball_track_Y[i,:]=ball['y']
            ball_track_Z[i,:]=ball['z']
        
        
        

        
        home_track_X[i,:]=home_players['x']
        home_track_Y[i,:]=home_players['y']
        home_track_jersey[i,:]=home_players['jerseyNum']
        
        away_track_X[i,:]=away_players['x']
        away_track_Y[i,:]=away_players['y']
        away_track_jersey[i,:]=away_players['jerseyNum']
        
    
        
        if i!=0:
            home_track_dist[i,:]=np.sqrt(np.square(home_track_X[i,:]-home_track_X[i-1,:])
                                            +np.square(home_track_Y[i,:]-home_track_Y[i-1,:]))
            away_track_dist[i,:]=np.sqrt(np.square(away_track_X[i,:]-away_track_X[i-1,:])
                                            +np.square(away_track_Y[i,:]-away_track_Y[i-1,:]))
            ball_track_dist[i,:]=np.sqrt(np.square(ball_track_X[i,:]-ball_track_X[i-1,:])
                                            +np.square(ball_track_Y[i,:]-ball_track_Y[i-1,:]))
                    
            home_track_dist_cum[i,:]=home_track_dist[i,:]+home_track_dist_cum[i-1,:]
            away_track_dist_cum[i,:]=away_track_dist[i,:]+away_track_dist_cum[i-1,:]
            
            if np.isnan(ball_track_dist[i,:]):
                ball_track_dist_cum[i,:]=ball_track_dist_cum[i-1,:]
            else:
                ball_track_dist_cum[i,:]=ball_track_dist[i,:]+ball_track_dist_cum[i-1,:]
                
            if i>2:
                home_track_speed[i,:]=abs((home_track_dist[i,:]-home_track_dist[i-1,:])/(2*avg_diff))
                away_track_speed[i,:]=abs((away_track_dist[i,:]-away_track_dist[i-1,:])/(2*avg_diff))
                ball_track_speed[i,:]=abs((ball_track_dist_cum[i,:]-ball_track_dist_cum[i-2,:])/(2*avg_diff))        
    
    
    else:
        
        home_mapping = dict(zip(home_roster['shirtNumber'], home_roster['nickname']))
        home_track_name = np.vectorize(home_mapping.get)(home_track_jersey)
        
    
        
        away_mapping = dict(zip(away_roster['shirtNumber'], away_roster['nickname']))
        away_track_name = np.vectorize(away_mapping.get)(away_track_jersey)
        
    return (home_track_X,home_track_Y,home_track_dist,home_track_dist_cum,home_track_jersey,
     home_track_name,home_track_speed,away_track_X,away_track_Y,away_track_dist,away_track_dist_cum,
     away_track_jersey,away_track_name,away_track_speed,ball_track_X,ball_track_Y,
     ball_track_Z,ball_track_dist,ball_track_dist_cum,ball_track_speed,
     game_time,avg_diff)
#%% Data processing functions

#Computes the area of the various voronoi domains,including the "infinite" ones
def voronoi_finite_polygons_2d(vor, radius=None):
    if radius is None:
        #radius = vor.points.ptp().max() * 2
        radius = np.ptp(vor.points, axis=0).max() * 2

    new_regions = []
    new_vertices = vor.vertices.tolist()

    center = vor.points.mean(axis=0)

    all_ridges = {}
    for (p1, p2), (v1, v2) in zip(vor.ridge_points, vor.ridge_vertices):
        all_ridges.setdefault(p1, []).append((p2, v1, v2))
        all_ridges.setdefault(p2, []).append((p1, v1, v2))

    for p1, region_idx in enumerate(vor.point_region):
        vertices = vor.regions[region_idx]

        if all(v >= 0 for v in vertices):
            new_regions.append(vertices)
            continue

        region = [v for v in vertices if v >= 0]
        
        for p2, v1, v2 in all_ridges[p1]:
            if v2 < 0:
                v1, v2 = v2, v1

            if v1 >= 0:
                continue

            tangent = vor.points[p2] - vor.points[p1]
            tangent /= np.linalg.norm(tangent)

            normal = np.array([-tangent[1], tangent[0]])

            midpoint = vor.points[[p1, p2]].mean(axis=0)
            direction = np.sign(
                np.dot(midpoint - center, normal)
            ) * normal

            far_point = vor.vertices[v2] + direction * radius

            region.append(len(new_vertices))
            new_vertices.append(far_point.tolist())

        vs = np.asarray([new_vertices[v] for v in region])
        c = vs.mean(axis=0)

        angles = np.arctan2(vs[:,1] - c[1], vs[:,0] - c[0])
        region = np.array(region)[np.argsort(angles)]

        new_regions.append(region.tolist())

    return new_regions, np.asarray(new_vertices)

#Calculates the voronoi plot infromation
def voronoi_calc(pitch_dim,frames,home_track_X,home_track_Y,away_track_X,
                away_track_Y):
    #Zero-index for speed
    vor_list = [None] * frames
    vor_areas= np.zeros((frames, 22))
    flag=0;
    
    #Loop through the data
    for i in range(frames):
        v_inp=np.column_stack([np.concatenate((home_track_X[i,:], away_track_X[i,:])),
                               np.concatenate((home_track_Y[i,:], away_track_Y[i,:]))])
        
        v_inp = perturb_duplicate_points(v_inp)

        vor_list[i]=Voronoi(v_inp)

        unique_points = np.unique(v_inp, axis=0)
        
        if len(unique_points) != len(v_inp):
            print("Duplicate points found")
            print("Original:", len(v_inp))
            print("Unique:", len(unique_points))
            print(flag)
            flag=flag+1
            

        #This calls our helper function
        regions, vertices = voronoi_finite_polygons_2d(vor_list[i])
        
        areas = []

        for region in regions:
            polygon = Polygon(vertices[region])
        
            clipped = polygon.intersection(pitch_dim)
        
            areas.append(clipped.area)
        vor_areas[i,:]=areas

    return (vor_areas,vor_list)

def perturb_duplicate_points(v_inp, eps=1e-5):
    """
    v_inp : ndarray of shape (n, 2)
            Column 0 = x, Column 1 = y

    Returns:
        ndarray with duplicate points slightly perturbed
    """

    v_out = v_inp.copy()

    for i in range(len(v_out)):
        for j in range(i):

            # If coordinates are identical
            if np.array_equal(v_out[i], v_out[j]):

                # Small random perturbation
                v_out[i, 0] += np.random.uniform(-eps, eps)
                v_out[i, 1] += np.random.uniform(-eps, eps)

    return v_out

def ball_z(sf_max,sf_min,ball_track_Z):    
    z_min = np.min(ball_track_Z)
    z_max = np.max(ball_track_Z)
    
    if z_max>0:
        sf = sf_min + ((ball_track_Z - z_min) / (z_max - z_min)) * (sf_max - sf_min)
    else:
        sf=sf_min*np.ones(len( ball_track_Z))

    return sf

# This function will find the shirt numbers of the input position
def find_position_numbers(roster_df, position):
    mapping = dict(zip(roster_df['shirtNumber'], roster_df['positionGroupType']))
    return {num for num, pos in mapping.items() if pos == position}

def rect_calcs(home_track_X_ngk,home_track_Y_ngk,away_track_X_ngk,away_track_Y_ngk):
    #home
    temp_minX=np.min(home_track_X_ngk,axis=1)
    temp_maxX=np.max(home_track_X_ngk,axis=1)
    temp_minY=np.min(home_track_Y_ngk,axis=1)
    temp_maxY=np.max(home_track_Y_ngk,axis=1)
    home_rect=np.column_stack([temp_minX, temp_minY, temp_maxX, temp_maxY,temp_maxX-temp_minX,temp_maxY-temp_minY])

    #away
    temp_minX=np.min(away_track_X_ngk,axis=1)
    temp_maxX=np.max(away_track_X_ngk,axis=1)
    temp_minY=np.min(away_track_Y_ngk,axis=1)
    temp_maxY=np.max(away_track_Y_ngk,axis=1)
    away_rect=np.column_stack([temp_minX, temp_minY, temp_maxX, temp_maxY,temp_maxX-temp_minX,temp_maxY-temp_minY])
    
    return home_rect, away_rect

def convex_calcs(frames,home_track_X_ngk,home_track_Y_ngk,away_track_X_ngk,away_track_Y_ngk):
    home_hull_volume=np.zeros(frames)
    away_hull_volume=np.zeros(frames)
    for i in range(frames):
        #home
        home_hull=ConvexHull(np.column_stack([home_track_X_ngk[i,:],home_track_Y_ngk[i,:]]))
        home_hull_volume[i]=home_hull.volume
        if i==0:
            home_hull_vertices=[home_hull.vertices]
        else:
            home_hull_vertices.append(np.array(home_hull.vertices))
        
        #away
        away_hull=ConvexHull(np.column_stack([away_track_X_ngk[i,:],away_track_Y_ngk[i,:]]))
        away_hull_volume[i]=away_hull.volume
        if i==0:
            away_hull_vertices=[away_hull.vertices]
        else:
            away_hull_vertices.append(np.array(away_hull.vertices))
            
    return (home_hull_vertices, away_hull_vertices, home_hull_volume,away_hull_volume)

#%% Position Identification

#Find the goal keepers
def find_gk(home_roster, home_track_jersey,home_track_X,home_track_Y, home_track_name,
            away_roster, away_track_jersey,away_track_X,away_track_Y, away_track_name):
    #Home
    home_gk_numbers = find_position_numbers(home_roster, 'GK')
    home_mask = np.isin(home_track_jersey, list(home_gk_numbers))
    home_track_X_ngk = home_track_X[:, ~home_mask.any(axis=0)]
    home_track_Y_ngk = home_track_Y[:, ~home_mask.any(axis=0)]
    home_track_name_ngk=home_track_name[:, ~home_mask.any(axis=0)]

    #Away
    away_gk_numbers = find_position_numbers(away_roster, 'GK')
    away_mask = np.isin(away_track_jersey, list(away_gk_numbers))
    away_track_X_ngk = away_track_X[:, ~away_mask.any(axis=0)]
    away_track_Y_ngk = away_track_Y[:, ~away_mask.any(axis=0)]
    away_track_name_ngk=away_track_name[:, ~away_mask.any(axis=0)]

    #Team centroids without the goal keepers
    home_centroid_ngk=np.column_stack([np.mean(home_track_X_ngk,axis=1),(np.mean(home_track_Y_ngk,axis=1))])
    away_centroid_ngk=np.column_stack([np.mean(away_track_X_ngk,axis=1),(np.mean(away_track_Y_ngk,axis=1))])
    cent_dist=np.sqrt(np.square(home_centroid_ngk[:,0]-away_centroid_ngk[:,0])+np.square(home_centroid_ngk[:,1]-away_centroid_ngk[:,1]))
    
    
    
      
    return (home_track_X_ngk,home_track_Y_ngk,home_track_name_ngk,away_track_X_ngk,
            away_track_Y_ngk,away_track_name_ngk,home_centroid_ngk,away_centroid_ngk,
            cent_dist)

def find_cent(home_rank1,home_rank2,home_rank3,home_rank4,home_track_X,home_track_Y,
              home_roster,home_track_jersey,away_rank1,away_rank2,away_rank3,away_rank4,
              away_track_X,away_track_Y,away_roster,away_track_jersey):
    
    #Find the first rank
    #Home
    for i in range(len(home_rank1)):
        if i==0:
            home_r1_numbers = find_position_numbers(home_roster, home_rank1[i])
        else:
            home_r1_numbers.update(find_position_numbers(home_roster, home_rank1[i]))
    home_mask = np.isin(home_track_jersey, list(home_r1_numbers))
    home_track_X_r1 = home_track_X[:, home_mask.any(axis=0)]
    home_track_Y_r1 = home_track_Y[:, home_mask.any(axis=0)]

    #Away
    for i in range(len(away_rank1)):
        if i==0:
            away_r1_numbers = find_position_numbers(away_roster, away_rank1[i])
        else:
            away_r1_numbers.update(find_position_numbers(away_roster, away_rank1[i]))
    away_mask = np.isin(away_track_jersey, list(away_r1_numbers))
    away_track_X_r1 = away_track_X[:, away_mask.any(axis=0)]
    away_track_Y_r1 = away_track_Y[:, away_mask.any(axis=0)]


    #Find the second rank
    #Home
    for i in range(len(home_rank2)):
        if i==0:
            home_r2_numbers = find_position_numbers(home_roster, home_rank2[i])
        else:
            home_r2_numbers.update(find_position_numbers(home_roster, home_rank2[i]))
    home_mask = np.isin(home_track_jersey, list(home_r2_numbers))
    home_track_X_r2 = home_track_X[:, home_mask.any(axis=0)]
    home_track_Y_r2 = home_track_Y[:, home_mask.any(axis=0)]

    #Away
    for i in range(len(away_rank2)):
        if i==0:
            away_r2_numbers = find_position_numbers(away_roster, away_rank2[i])
        else:
            away_r2_numbers.update(find_position_numbers(away_roster, away_rank2[i]))
    away_mask = np.isin(away_track_jersey, list(away_r2_numbers))
    away_track_X_r2 = away_track_X[:, away_mask.any(axis=0)]
    away_track_Y_r2 = away_track_Y[:, away_mask.any(axis=0)]


    #Find the third rank
    #Home
    for i in range(len(home_rank3)):
        if i==0:
            home_r3_numbers = find_position_numbers(home_roster, home_rank3[i])
        else:
            home_r3_numbers.update(find_position_numbers(home_roster, home_rank3[i]))
    home_mask = np.isin(home_track_jersey, list(home_r3_numbers))
    home_track_X_r3 = home_track_X[:, home_mask.any(axis=0)]
    home_track_Y_r3 = home_track_Y[:, home_mask.any(axis=0)]

    #Away
    for i in range(len(away_rank3)):
        if i==0:
            away_r3_numbers = find_position_numbers(away_roster, away_rank3[i])
        else:
            away_r3_numbers.update(find_position_numbers(away_roster, away_rank3[i]))
    away_mask = np.isin(away_track_jersey, list(away_r3_numbers))
    away_track_X_r3 = away_track_X[:, away_mask.any(axis=0)]
    away_track_Y_r3 = away_track_Y[:, away_mask.any(axis=0)]

    #Find the forth rank, if it exists
    if len(home_rank4)!=0:
    #Home
        for i in range(len(home_rank4)):
            if i==0:
                home_r4_numbers = find_position_numbers(home_roster, home_rank4[i])
            else:
                home_r4_numbers.update(find_position_numbers(home_roster, home_rank4[i]))
        home_mask = np.isin(home_track_jersey, list(home_r4_numbers))
        home_track_X_r4 = home_track_X[:, home_mask.any(axis=0)]
        home_track_Y_r4 = home_track_Y[:, home_mask.any(axis=0)]
        home_centroids=np.column_stack([np.mean(home_track_X_r1,axis=1),np.mean(home_track_Y_r1,axis=1),
                                        np.mean(home_track_X_r2,axis=1),np.mean(home_track_Y_r2,axis=1),
                                        np.mean(home_track_X_r3,axis=1),np.mean(home_track_Y_r3,axis=1),
                                        np.mean(home_track_X_r4,axis=1),np.mean(home_track_Y_r4,axis=1)])
        
        home_cent_dist=np.column_stack([np.sqrt(np.square(home_centroids[:,0]-home_centroids[:,2])+np.square(home_centroids[:,1]-home_centroids[:,3])),
                                       np.sqrt(np.square(home_centroids[:,2]-home_centroids[:,4])+np.square(home_centroids[:,3]-home_centroids[:,5])),
                                       np.sqrt(np.square(home_centroids[:,4]-home_centroids[:,6])+np.square(home_centroids[:,5]-home_centroids[:,7]))])
    else:
        home_track_X_r4=0
        home_track_Y_r4=0
        
        home_centroids=np.column_stack([np.mean(home_track_X_r1,axis=1),np.mean(home_track_Y_r1,axis=1),
                                        np.mean(home_track_X_r2,axis=1),np.mean(home_track_Y_r2,axis=1),
                                        np.mean(home_track_X_r3,axis=1),np.mean(home_track_Y_r3,axis=1)])
        home_cent_dist=np.column_stack([np.sqrt(np.square(home_centroids[:,0]-home_centroids[:,2])+np.square(home_centroids[:,1]-home_centroids[:,3])),
                                       np.sqrt(np.square(home_centroids[:,2]-home_centroids[:,4])+np.square(home_centroids[:,3]-home_centroids[:,5]))])
    if len(away_rank4)!=0:
    #Away
        for i in range(len(away_rank4)):
            if i==0:
                away_r4_numbers = find_position_numbers(away_roster, away_rank4[i])
            else:
                away_r4_numbers.update(find_position_numbers(away_roster, away_rank4[i]))
        away_mask = np.isin(away_track_jersey, list(away_r4_numbers))
        away_track_X_r4 = away_track_X[:, away_mask.any(axis=0)]
        away_track_Y_r4 = away_track_Y[:, away_mask.any(axis=0)]
        away_centroids=np.column_stack([np.mean(away_track_X_r1,axis=1),np.mean(away_track_Y_r1,axis=1),
                                        np.mean(away_track_X_r2,axis=1),np.mean(away_track_Y_r2,axis=1),
                                        np.mean(away_track_X_r3,axis=1),np.mean(away_track_Y_r3,axis=1),
                                        np.mean(away_track_X_r4,axis=1),np.mean(away_track_Y_r4,axis=1)])
        
        away_cent_dist=np.column_stack([np.sqrt(np.square(away_centroids[:,0]-away_centroids[:,2])+np.square(away_centroids[:,1]-away_centroids[:,3])),
                                       np.sqrt(np.square(away_centroids[:,2]-away_centroids[:,4])+np.square(away_centroids[:,3]-away_centroids[:,5])),
                                       np.sqrt(np.square(away_centroids[:,4]-away_centroids[:,6])+np.square(away_centroids[:,5]-away_centroids[:,7]))])
        
        
        
    else:
        away_track_X_r4=0
        away_track_Y_r4=0
        away_centroids=np.column_stack([np.mean(away_track_X_r1,axis=1),np.mean(away_track_Y_r1,axis=1),
                                        np.mean(away_track_X_r2,axis=1),np.mean(away_track_Y_r2,axis=1),
                                        np.mean(away_track_X_r3,axis=1),np.mean(away_track_Y_r3,axis=1)])
        
        away_cent_dist=np.column_stack([np.sqrt(np.square(away_centroids[:,0]-away_centroids[:,2])+np.square(away_centroids[:,1]-away_centroids[:,3])),
                                       np.sqrt(np.square(away_centroids[:,2]-away_centroids[:,4])+np.square(away_centroids[:,3]-away_centroids[:,5]))])
        
    return (home_track_X_r1, home_track_X_r2,home_track_X_r3,home_track_X_r4,
            home_track_Y_r1, home_track_Y_r2,home_track_Y_r3,home_track_Y_r4,
            away_track_X_r1, away_track_X_r2,away_track_X_r3,away_track_X_r4,
            away_track_Y_r1, away_track_Y_r2,away_track_Y_r3,away_track_Y_r4,
            home_centroids,away_centroids,home_cent_dist,away_cent_dist)
            
# %% Plotting

def scatter(ax,pitch,t,ss,ld,fs,sf,player_colours,home_track_X,home_track_Y,
 home_track_name,away_track_X,away_track_Y,away_track_name,ball_track_X,
 ball_track_Y,bool_player_surname_only,bool_player_name,
 bool_team_centroid,bool_ball):
    # Home
    ax.scatter(t*home_track_X, t*home_track_Y, color=player_colours[0],edgecolors=player_colours[1],s=ss)
    # Away
    ax.scatter(t*away_track_X, t*away_track_Y, color=player_colours[2],edgecolors=player_colours[3],s=ss)

    if bool_player_surname_only:
        get_surname = np.vectorize(lambda s: s.split()[-1])
        home_track_name = get_surname(home_track_name)
        away_track_name = get_surname(away_track_name)

    if bool_player_name and bool_team_centroid==False:
        for xi, yi, label in zip(t*home_track_X, t*home_track_Y+ld,home_track_name):
            ax.text(xi, yi, label, fontsize=fs, ha='center', va='center')
        for xi, yi, label in zip(t*away_track_X, t*away_track_Y+ld,away_track_name):
            ax.text(xi, yi, label, fontsize=fs, ha='center', va='center')

    if bool_ball:
        pitch.scatter(t*ball_track_X, t*ball_track_Y,c='white',marker='football',ax=ax,s=sf)
        
def plot_distance_and_speed(ax,t,ld,fs,home_track_X,home_track_Y,away_track_X,
    away_track_Y,ball_track_X,ball_track_Y,home_track_dist_cum,away_track_dist_cum,
    ball_track_dist_cum,home_track_speed,away_track_speed,ball_track_speed,
    bool_cum_dist,bool_speed):
    # Home
    if bool_cum_dist:
        for xi, yi, label in zip(t*home_track_X, t*home_track_Y-ld,np.round(home_track_dist_cum,2)):
            ax.text(xi, yi, str(label)+"m", fontsize=fs, ha='center', va='center')
    # Away
        for xi, yi, label in zip(t*away_track_X, t*away_track_Y-ld,np.round(away_track_dist_cum,2)):
            ax.text(xi, yi, str(label)+"m", fontsize=fs, ha='center', va='center')
    # Ball
        for xi, yi, label in zip(t*ball_track_X, t*ball_track_Y-ld,np.round(ball_track_dist_cum,2)):
            ax.text(xi, yi, str(label)+"m", fontsize=fs, ha='center', va='center')
            
    ## Speed
    # Home
    if bool_speed:
        for xi, yi, label in zip(t*home_track_X, t*home_track_Y-ld,np.round(home_track_speed,2)):
            ax.text(xi, yi, str(label)+"$ms^{-1}$", fontsize=fs, ha='center', va='center')
    # Away
        for xi, yi, label in zip(t*away_track_X, t*away_track_Y-ld,np.round(away_track_speed,2)):
            ax.text(xi, yi, str(label)+"$ms^{-1}$", fontsize=fs, ha='center', va='center')
    # Ball
        for xi, yi, label in zip(t*ball_track_X, t*ball_track_Y-ld,np.round(ball_track_speed,2)):
            ax.text(xi, yi, str(label)+"$ms^{-1}$", fontsize=fs, ha='center', va='center')
    
def plot_rectangles(t, home_rect, away_rect, ax, contrast_colours, fs, bool_rectangle):
    ##Rectangle
    if bool_rectangle:
        #home
        #rectangle
        ax.plot([t*home_rect[0],t*home_rect[0],t*home_rect[2],t*home_rect[2],t*home_rect[0]],
                [t*home_rect[1],t*home_rect[3],t*home_rect[3],t*home_rect[1],t*home_rect[1]],
                color=contrast_colours[0])
        #width
        ax.text((t*home_rect[0]+t*home_rect[2])/2, t*home_rect[3]+2,str(np.round(home_rect[4],2))+"m",
                 fontsize=fs, ha='center', va='center',c=contrast_colours[0])
        #length
        ax.text(t*home_rect[0]-4, (t*home_rect[1]+t*home_rect[3])/2,str(np.round(home_rect[5],2))+"m",
                 fontsize=fs, ha='center', va='center',c=contrast_colours[0])
        #ratio
        ax.text(t*-42, 32 ,"Home L/W Ratio " +str(np.round(home_rect[5]/home_rect[4],2)),
                 fontsize=fs, ha='center', va='center',c=contrast_colours[0])
        
        #away
        #rectangle
        ax.plot([t*away_rect[0],t*away_rect[0],t*away_rect[2],t*away_rect[2],t*away_rect[0]],
                [t*away_rect[1],t*away_rect[3],t*away_rect[3],t*away_rect[1],t*away_rect[1]],
                color=contrast_colours[2])
        #width
        ax.text((t*away_rect[0]+t*away_rect[2])/2, t*away_rect[1]-2,str(np.round(away_rect[4],2))+"m",
                 fontsize=fs, ha='center', va='center',c=contrast_colours[2])
        #length
        ax.text(t*away_rect[2]+4, (t*away_rect[1]+t*away_rect[3])/2,str(np.round(away_rect[5],2))+"m",
                 fontsize=fs, ha='center', va='center',c=contrast_colours[2])
        #ratio
        ax.text(t*42, 32 ,"Away L/W Ratio " +str(np.round(away_rect[5]/away_rect[4],2)),
                 fontsize=fs, ha='center', va='center',c=contrast_colours[2])
        
def plot_centroids(i,t, ax, fs, ss, cs,
        bool_centroids, bool_centroids_home, bool_centroids_away, bool_centroids_connector,
        home_track_X_r1, home_track_X_r2, home_track_X_r3, home_track_X_r4,
        home_track_Y_r1, home_track_Y_r2, home_track_Y_r3, home_track_Y_r4,
        away_track_X_r1, away_track_X_r2, away_track_X_r3, away_track_X_r4,
        away_track_Y_r1, away_track_Y_r2, away_track_Y_r3, away_track_Y_r4,
        home_centroids, away_centroids,home_cent_dist, away_cent_dist,
        home_rank4, away_rank4,dot_colours):
    ##Centroids
    if bool_centroids:
        if bool_centroids_home:
            #home
            #Rear
            ax.scatter(t*home_track_X_r1[:], t*home_track_Y_r1[:], color=dot_colours[0],s=ss,alpha=0.5)
            ax.scatter(t*home_centroids[0], t*home_centroids[1], color=dot_colours[0],s=cs)
            #r2
            ax.scatter(t*home_track_X_r2[:], t*home_track_Y_r2[:], color=dot_colours[1],s=ss,alpha=0.5)
            ax.scatter(t*home_centroids[2], t*home_centroids[3], color=dot_colours[1],s=cs)
            #forwards
            ax.scatter(t*home_track_X_r3[:], t*home_track_Y_r3[:], color=dot_colours[2],s=ss,alpha=0.5)
            ax.scatter(t*home_centroids[4], t*home_centroids[5], color=dot_colours[2],s=cs)
            if len(home_rank4)!=0:
                ax.scatter(t*home_track_X_r4[i,:], t*home_track_Y_r4[i,:], color=dot_colours[3],s=ss,alpha=0.5)
                ax.scatter(t*home_centroids[6], t*home_centroids[7], color=dot_colours[3],s=cs)
        
        if bool_centroids_away:
            #away
            #r1
            ax.scatter(t*away_track_X_r1[:], t*away_track_Y_r1[:], color=dot_colours[9],s=ss,alpha=0.5)
            ax.scatter(t*away_centroids[0], t*away_centroids[1], color=dot_colours[9],s=cs)
            #r2
            ax.scatter(t*away_track_X_r2[:], t*away_track_Y_r2[:], color=dot_colours[8],s=ss,alpha=0.5)
            ax.scatter(t*away_centroids[2], t*away_centroids[3], color=dot_colours[8],s=cs)
            #forwards
            ax.scatter(t*away_track_X_r3[:], t*away_track_Y_r3[:], color=dot_colours[7],s=ss,alpha=0.5)
            ax.scatter(t*away_centroids[4], t*away_centroids[5], color=dot_colours[7],s=cs)
            if len(away_rank4)!=0:
                ax.scatter(t*away_track_X_r4[i,:], t*away_track_Y_r4[i,:], color=dot_colours[5],s=ss,alpha=0.5)
                ax.scatter(t*away_centroids[6], t*away_centroids[7], color=dot_colours[5],s=cs)
        
        if bool_centroids_connector:
            if bool_centroids_home:
                #home
                #Centroid Connectors
                ax.plot([t*home_centroids[0],t*home_centroids[2]],[t*home_centroids[1],t*home_centroids[3]],'black')
                ax.plot([t*home_centroids[2],t*home_centroids[4]],[t*home_centroids[3],t*home_centroids[5]],'black')
                #Centroid distance
                #ratio
                ax.text(t*(home_centroids[0]+home_centroids[2])/2, t*(home_centroids[1]+home_centroids[3])/2+2.5,
                         str(np.round(home_cent_dist[0],2))+"m",
                         fontsize=fs, ha='center', va='center',c='black')
                ax.text(t*(home_centroids[2]+home_centroids[4])/2, t*(home_centroids[3]+home_centroids[5])/2+2.5,
                         str(np.round(home_cent_dist[1],2))+"m",
                         fontsize=fs, ha='center', va='center',c='black')
                if len(home_rank4)!=0:
                    ax.plot([t*home_centroids[4],t*home_centroids[6]],[t*home_centroids[5],t*home_centroids[7]],'black')
                    ax.text(t*(home_centroids[4]+home_centroids[6])/2, t*(home_centroids[5]+home_centroids[7])/2+2.5,
                             str(np.round(home_cent_dist[2],2))+"m",
                             fontsize=fs, ha='center', va='center',c='black')
            if bool_centroids_away:
                #away
                #Centroid Connectors
                ax.plot([t*away_centroids[0],t*away_centroids[2]],[t*away_centroids[1],t*away_centroids[3]],'black')
                ax.plot([t*away_centroids[2],t*away_centroids[4]],[t*away_centroids[3],t*away_centroids[5]],'black')
                #Centroid distance
                #ratio
                ax.text(t*(away_centroids[0]+away_centroids[2])/2, t*(away_centroids[1]+away_centroids[3])/2+2.5,
                         str(np.round(away_cent_dist[0],2))+"m",
                         fontsize=fs, ha='center', va='center',c='black')
                ax.text(t*(away_centroids[2]+away_centroids[4])/2, t*(away_centroids[3]+away_centroids[5])/2+2.5,
                         str(np.round(away_cent_dist[1],2))+"m",
                         fontsize=fs, ha='center', va='center',c='black')
                if len(away_rank4)!=0:
                    ax.plot([t*away_centroids[4],t*away_centroids[6]],[t*away_centroids[5],t*away_centroids[7]],'black')
                    ax.text(t*(away_centroids[4]+away_centroids[6])/2, t*(away_centroids[5]+away_centroids[7])/2+2.5,
                             str(np.round(away_cent_dist[2],2))+"m",
                             fontsize=fs, ha='center', va='center',c='black')
    
def plot_convex_hulls(t, ax, fs,bool_convex,home_hull_vertices, away_hull_vertices,
        home_track_X_ngk, home_track_Y_ngk,away_track_X_ngk, away_track_Y_ngk,
        home_hull_volume, away_hull_volume, player_colours):
    
    if bool_convex:
        #Home
        #Initalise for speed
        convex_x=np.zeros(len(home_hull_vertices))
        convex_y=np.zeros(len(home_hull_vertices))
        
        #find the verticies
        for j in range(len(home_hull_vertices)):
            convex_x[j]=home_track_X_ngk[home_hull_vertices[j]]
            convex_y[j]=home_track_Y_ngk[home_hull_vertices[j]]
            
        #Plot hull and text
        ax.fill(t*convex_x,t*convex_y,alpha=0.3,c=player_colours[1],edgecolor="none")
        ax.text(t*-40, -32 ,"Convex Hull Area " +str(np.round(home_hull_volume,2))+"m$^2$",
                 fontsize=fs, ha='center', va='center',c=player_colours[1])

        #Away
        #Initalise for speed
        convex_x=np.zeros(len(away_hull_vertices))
        convex_y=np.zeros(len(away_hull_vertices))
        
        #find the verticies
        for j in range(len(away_hull_vertices)):
            convex_x[j]=away_track_X_ngk[away_hull_vertices[j]]
            convex_y[j]=away_track_Y_ngk[away_hull_vertices[j]]
            
        #Plot hull and text
        ax.fill(t*convex_x,t*convex_y,alpha=0.3,c=player_colours[3],edgecolor="none")
        ax.text(t*40, -32 ,"Convex Hull Area " +str(np.round(away_hull_volume,2))+"m$^2$",
                 fontsize=fs, ha='center', va='center',c=player_colours[3])
        
def plot_voronoi(t, ax, fs, ld,bool_voronoi, bool_voronoi_colour, bool_highlight_player,
        vor_list, vor_areas,home_track_X, home_track_Y,away_track_X, away_track_Y,
        pitch_dim,contrast_colours, voronoi_players):
    if bool_voronoi:
        v_inp=np.column_stack([np.concatenate((home_track_X, away_track_X)),
                               np.concatenate((home_track_Y, away_track_Y))])
        vor_list=Voronoi(t*v_inp)
        regions, vertices = voronoi_finite_polygons_2d(vor_list)
        voronoi_plot_2d(vor_list,ax=ax,show_vertices=False,show_points=False)

        
        for xi, yi, label in zip(t*v_inp[:,0], t*v_inp[:,1],np.round(vor_areas)):
            ax.text(xi, yi-ld, str(int(label))+"m$^2$", fontsize=fs, ha='center', va='center')
        
        if bool_voronoi_colour:        
            for j, region in enumerate(regions):
                
                polygon = Polygon(vertices[region])
                clipped = polygon.intersection(pitch_dim)
            
                if clipped.is_empty:
                    continue
            
                x, y = clipped.exterior.xy
            
                colour = contrast_colours[0] if j < 11 else contrast_colours[2]
                
                if bool_highlight_player and str(j) in voronoi_players:
                    
                    ax.fill(x,y,color=colour,alpha=0.4,edgecolor='none')
                else:
                    ax.fill(x,y,color=colour,alpha=0.2,edgecolor='none')

def plot_distances(t, ax, fs, ld, lw, bool_dist, bool_dist_home, bool_dist_comp_home, 
                   bool_dist_comp_away, bool_dist_line, bool_dist_disp, dist_player,
                   home_track_X, home_track_Y, away_track_X, away_track_Y):
    if bool_dist:
        #Setup the data
        if bool_dist_home:
            target_X=home_track_X[dist_player]
            target_Y=home_track_Y[dist_player]
            home_track_X_dist=np.delete(home_track_X, dist_player, axis=0)
            home_track_Y_dist=np.delete(home_track_Y, dist_player, axis=0)
            away_track_X_dist=away_track_X
            away_track_Y_dist=away_track_Y
            
        else:
            target_X=away_track_X[dist_player]
            target_Y=away_track_Y[dist_player]
            away_track_X_dist=np.delete(away_track_X, dist_player, axis=0)
            away_track_Y_dist=np.delete(away_track_Y, dist_player, axis=0)
            home_track_X_dist=home_track_X
            home_track_Y_dist=home_track_Y
        
        #Distance to home players
        if bool_dist_comp_home:
            home_dist_2target=np.zeros(np.shape(home_track_X_dist))
            for j in range(len(home_track_X_dist)):
                home_dist_2target[j]=np.sqrt(np.square(home_track_X_dist[j]-target_X)+
                                        np.square(home_track_Y_dist[j]-target_Y))

        #Distance to away players
        if bool_dist_comp_away:
            away_dist_2target=np.zeros(np.shape(away_track_X_dist))
            for j in range(len(away_track_X_dist)):
                away_dist_2target[j]=np.sqrt(np.square(away_track_X_dist[j]-target_X)+
                                        np.square(away_track_Y_dist[j]-target_Y))

        #Home
        if bool_dist_comp_home:
            #Plot lines
            if bool_dist_line:
                for j in range(len(home_track_X_dist)):
                    ax.plot([t*target_X,t*home_track_X_dist[j]],[t*target_Y,t*home_track_Y_dist[j]],'k--',linewidth=lw)
            #Distance
            if bool_dist_disp:
                for xi, yi, label in zip(t*home_track_X_dist[:], t*home_track_Y_dist[:],np.round(home_dist_2target[:],2)):
                    ax.text(xi, yi-ld, str(label)+"m", fontsize=fs, ha='center', va='center')
                    
        #Away
        if bool_dist_comp_away:
            #Plot lines
            if bool_dist_line:
                for j in range(len(away_track_X_dist)):
                    ax.plot([t*target_X,t*away_track_X_dist[j]],[t*target_Y,t*away_track_Y_dist[j]],'k--',linewidth=lw)
            #Distance
            if bool_dist_disp:
                for xi, yi, label in zip(t*away_track_X_dist[:], t*away_track_Y_dist[:],np.round(away_dist_2target[:],2)):
                    ax.text(xi, yi-ld, str(label)+"m", fontsize=fs, ha='center', va='center')
    
def plot_team_centroids(t, ax, fs, ld, ss, cs, bool_team_centroid, bool_player_name, 
                        bool_centroids_connector,home_track_X_ngk, home_track_Y_ngk,
                        away_track_X_ngk, away_track_Y_ngk, home_centroid_ngk,
                        away_centroid_ngk, home_track_name_ngk, away_track_name_ngk,
                        cent_dist, player_colours,bool_player_surname_only):
    if bool_team_centroid:
            #home
            ax.scatter(t*home_track_X_ngk, t*home_track_Y_ngk, color=player_colours[0],
                       edgecolors=player_colours[1],s=ss,alpha=0.5)
            ax.scatter(t*home_centroid_ngk[0], t*home_centroid_ngk[1], color=player_colours[0],
                       edgecolors=player_colours[1],s=cs)
            #away
            ax.scatter(t*away_track_X_ngk, t*away_track_Y_ngk, color=player_colours[2],
                       edgecolors=player_colours[3],s=ss,alpha=0.5)
            ax.scatter(t*away_centroid_ngk[0], t*away_centroid_ngk[1], color=player_colours[2],
                       edgecolors=player_colours[3],s=cs)        
            if bool_player_surname_only:
                get_surname = np.vectorize(lambda s: s.split()[-1])
                home_track_name_ngk = get_surname(home_track_name_ngk)
                away_track_name_ngk = get_surname(away_track_name_ngk)
            #player name_ngk
            if bool_player_name:
                for xi, yi, label in zip(t*home_track_X_ngk, t*home_track_Y_ngk,home_track_name_ngk):
                    ax.text(xi, yi+ld, label, fontsize=fs, ha='center', va='center')
                for xi, yi, label in zip(t*away_track_X_ngk, t*away_track_Y_ngk,away_track_name_ngk):
                    ax.text(xi, yi+ld, label, fontsize=fs, ha='center', va='center')
            if bool_centroids_connector:
                #home
                #Centroid Connectors
                ax.plot([t*home_centroid_ngk[0],t*away_centroid_ngk[0]],[t*home_centroid_ngk[1],t*away_centroid_ngk[1]],'black')
                #Centroid distance
                ax.text(t*(home_centroid_ngk[0]+away_centroid_ngk[0])/2, t*(home_centroid_ngk[1]+away_centroid_ngk[1])/2+2.5,
                         str(np.round(cent_dist,2))+"m",
                         fontsize=fs, ha='center', va='center',c='black')

def plot_dots(ax, t, fs, ss, ld,bool_dot, bool_dots_ps,dots_per_position, dots_per_second,
        game_time, frames,dots_players,bool_dots_home,home_track_X, home_track_Y, home_track_jersey,
        away_track_X, away_track_Y, away_track_jersey,home_centroid_ngk, away_centroid_ngk,
        home_roster,dot_colours):
    
    if bool_dot:
        
        if bool_dots_ps==False:
            #Generate evenly spaced indices
            idx = np.linspace(0, len(home_track_X) - 1, dots_per_position, dtype=int)
        else:

            # Create threshold values: 0.5, 1.0, 1.5, ...
            thresholds = np.arange(
                dots_per_second,
                game_time[frames-1] + dots_per_second,
                dots_per_second
            )
            
            # Find first index where game_time >= each threshold
            idx = np.searchsorted(game_time, thresholds)
            idx=idx[:-1]
            
        dots_X=np.zeros((len(idx),len(dots_players)))
        dots_Y=np.zeros((len(idx),len(dots_players)))
        dots_jersey=np.zeros((len(idx),len(dots_players)))
            
        for i in range(len(dots_players)):
            if bool_dots_home:
                dots_X[:,i]=home_track_X[idx,int(dots_players[i])]-home_centroid_ngk[idx,0]
                dots_Y[:,i]=home_track_Y[idx,int(dots_players[i])]-home_centroid_ngk[idx,1]
                dots_jersey[:,i]=home_track_jersey[idx,int(dots_players[i])]
                # Create jersey -> position lookup
                jersey_to_position = dict(zip(home_roster["shirtNumber"],
                                              home_roster["positionGroupType"]))
                dots_position = np.array([jersey_to_position.get(jersey) for jersey in dots_jersey[0,:]])

                
            else:
                dots_X[:,i]=away_track_X[idx,int(dots_players[i])]-away_centroid_ngk[idx,0]
                dots_Y[:,i]=away_track_Y[idx,int(dots_players[i])]-away_centroid_ngk[idx,1]
                dots_jersey[:,i]=away_track_jersey[idx,int(dots_players[i])]
                jersey_to_position = dict(zip(home_roster["shirtNumber"],
                                              home_roster["positionGroupType"]))
                dots_position = np.array([jersey_to_position.get(jersey) for jersey in dots_jersey[0,:]])
            
            ax.scatter(dots_X[:,i],dots_Y[:,i],s=ss,c=dot_colours[i],label=dots_position[i])
            ax.legend(title="Position",loc='lower left')
            
def record_data(end_rec,home_data,away_data, bool_axis_label,sf,home_track_X,home_track_Y,
                home_track_name, away_track_X, away_track_Y, away_track_name, ball_track_X,
                ball_track_Y, bool_player_surname_only, bool_player_name, bool_ball,
                avg_diff, bool_flip_ends,bool_generic_colours, contrast_colours,
                ss,ld,fs,dpi_inp,start_rec,recording_name,pb_speed):
    
    frames_list = []
    os.makedirs("frames", exist_ok=True)
    start_time = time.time()
        

    for i in range(start_rec,end_rec):          
        #Create the translation matrix to flip
        if bool_flip_ends:
            t=-1
        else:
            t=1


        if bool_generic_colours:
            player_colours=contrast_colours
        else:
            player_colours=[home_data.iloc[0,2],home_data.iloc[0,3],away_data.iloc[0,2],away_data.iloc[0,3]]
            
        pitch = Pitch(pitch_type='skillcorner', pitch_length=105, pitch_width=68,label=bool_axis_label,corner_arcs=True)
        fig, ax = pitch.draw()
        

        ## Player location
        scatter(ax,pitch,t,ss,ld,fs,sf[i],player_colours,home_track_X[i,:],home_track_Y[i,:],
         home_track_name[i,:],away_track_X[i,:],away_track_Y[i,:],away_track_name[i,:],ball_track_X[i,:],
         ball_track_Y[i,:],bool_player_surname_only,bool_player_name,
         False,bool_ball)



        ax.set_title(home_data.iloc[0,0]+" vs "+away_data.iloc[0,0])
        ax.set_xlabel('X Position (m)')
        ax.set_ylabel('Y Position (m)')
        ax.set_xlim(pitch.dim.left, pitch.dim.right)
        ax.set_ylim(pitch.dim.bottom, pitch.dim.top)
        #Saving figures
        plt.savefig(f"frames/frame_{i:04d}.png", dpi=dpi_inp)
        plt.clf()
        plt.close()
    
        frames_list.append(imageio.imread(f"frames/frame_{i:04d}.png"))
    #imageio.mimsave("match_animation.gif", frames_list, duration=0.05)
    # Read first frame to get size
    first_frame = imageio.imread(f"frames/frame_{start_rec:04d}.png")
    height, width, _ = first_frame.shape
    
    # Create MP4 writer (H.264 baseline)
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")   # Windows-friendly codec
    video = cv2.VideoWriter(recording_name+".mp4", fourcc, pb_speed*1/avg_diff, (width, height))
    
    # Write frames
    for i in range(start_rec,end_rec):
        frame = imageio.imread(f"frames/frame_{i:04d}.png")
        frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
        video.write(frame_bgr)
    
    video.release()
    shutil.rmtree("frames", ignore_errors=True)
    os.makedirs("frames", exist_ok=True)
    print("Data Recorded --- %s seconds ---" % (time.time() - start_time))

def event_process(game_id,event_map):
    cwd=os.getcwd()
    data_loc=cwd+"\\Tracking Data\\"+str(game_id)+".jsonl\\"+str(game_id)+".jsonl"
    event_data_loc=cwd+"\\User Defined Events\\"+str(game_id)+"\\"+str(game_id)+"User_Defined_Events.csv"

    event_tab = pd.read_csv(event_data_loc)
    print(event_tab.head())

    with open(data_loc, "r", encoding="utf-8") as f:
        n_frames = sum(1 for _ in f)
        

    # Initialise array
    press_log = np.zeros(n_frames, dtype=int)

    # Event -> value mapping


    # Populate array
    for _, row in event_tab.iterrows():

        start = int(row["Start Frame"])
        end   = int(row["End Frame"])
        event = row["Event Name"]

        if event in event_map:
            press_log[start:end+1] = event_map[event]

    return press_log
