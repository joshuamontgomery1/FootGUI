# %% Import the Python

import os
os.environ["QT_API"] = "PySide6"

import matplotlib
matplotlib.use("qtagg")

#from matplotlib.backends.qt_compat import QT_API
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
import pandas as pd
import numpy as np
import ast
#from scipy.spatial import ConvexHull
#from scipy.spatial import Voronoi, voronoi_plot_2d 
from shapely.geometry import Polygon
import os 
import time
from mplsoccer import Pitch
import json
import traceback

import imageio.v2 as imageio
import cv2 #pip install opencv-python
import shutil
import sys
from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QDoubleSpinBox, QGraphicsView,
    QGridLayout, QHBoxLayout, QLabel, QLineEdit, QDialog,
    QMainWindow, QPushButton, QSizePolicy, QSlider,
    QSpacerItem, QSpinBox, QStatusBar, QTabWidget,
    QTextEdit, QVBoxLayout, QWidget)
from PySide6.QtGui import QShortcut, QKeySequence

#User created functions
from FootGUI_backend import (meta_extract, 
    roster_extract, track_extract,rect_calcs,convex_calcs,find_gk, find_cent,
    voronoi_calc,scatter,ball_z,plot_distance_and_speed, plot_rectangles,
    plot_centroids, plot_convex_hulls, plot_voronoi,plot_distances,
    plot_team_centroids,plot_dots)


#Dots should deactivate the time variant stuff

class Ui_MainWindow(object):
    def load_data(self):
        try:
            start_time = time.time()
            
            self.pitch_dim = Polygon([(-52.5, -34),( 52.5, -34),( 52.5,  34),(-52.5,  34)])
            
            cwd = os.getcwd()
            game_id = self.game_id.value()
            frames= self.frames_inp.value()
            
            #File location
            if self.check_load_event.isChecked():
                data_loc=cwd+"\\User Defined Events\\"+self.event_load_name.text()+".jsonl"
                self.raw = pd.read_json(data_loc,lines=True)
                self.raw = self.raw[
                    self.raw["homePlayersSmoothed"].apply(
                        lambda x: isinstance(x, list) and len(x) == 11
                    )
                ]
                
                self.raw = self.raw[
                    self.raw["awayPlayersSmoothed"].apply(
                        lambda x: isinstance(x, list) and len(x) == 11
                    )
                ]
                
                frames=self.raw.shape[0]

            else:
                data_loc=cwd+"\\Tracking Data\\"+str(game_id)+".jsonl\\"+str(game_id)+".jsonl"
                self.raw = pd.read_json(data_loc,lines=True,nrows=frames)
                self.raw = self.raw[
                    self.raw["homePlayersSmoothed"].apply(
                        lambda x: isinstance(x, list) and len(x) == 11
                    )
                ]
                
                self.raw = self.raw[
                    self.raw["awayPlayersSmoothed"].apply(
                        lambda x: isinstance(x, list) and len(x) == 11
                    )
                ]
                
                self.raw = self.raw.reset_index(drop=True)
                frames=self.raw.shape[0]
                
            roster_loc=cwd+"\\Rosters\\"+str(game_id)+".json"
            meta_loc=cwd+"\\Metadata\\"+str(game_id)+".json"
            
            #For Use with the event log
            self.raw_data_loc=data_loc
            #Ensure int
            frames=int(frames)
            self.frames=frames
            # %% Data Imported 
            #This section uses user-defined functions for clarity
            
            #Import the meta data
            [self.away_team,self.away_kit,self.away_data,self.home_team,self.home_kit,
             self.home_data]=meta_extract(meta_loc)
            #Import the roster_data
            (self.home_roster,self.away_roster)=roster_extract(roster_loc,self.home_data,self.away_data)
            #Import the tracking data

            (self.home_track_X,self.home_track_Y,self.home_track_dist,self.home_track_dist_cum,self.home_track_jersey,
             self.home_track_name,self.home_track_speed,self.away_track_X,self.away_track_Y,self.away_track_dist,self.away_track_dist_cum,
             self.away_track_jersey,self.away_track_name,self.away_track_speed,self.ball_track_X,self.ball_track_Y,
             self.ball_track_Z,self.ball_track_dist,self.ball_track_dist_cum,self.ball_track_speed,
            self.game_time,self.avg_diff)=track_extract(data_loc,frames,self.home_roster,self.away_roster,self.raw)
            for i in range(frames):

                if len(self.home_track_X[i]) != 11:
                    print("Bad home frame", i)
            
                if len(self.away_track_X[i]) != 11:
                    print("Bad away frame", i)
            self.data_loaded = True
            self.horizontalSlider.setMaximum(len(self.game_time)-1)
            
            self.bool_rectangle = False
            self.bool_convex = False
            self.bool_voronoi = False
            self.bool_dist = False
            self.bool_dot = False
            self.bool_team_centroid = False
            self.bool_centroids = False
        
            
            print("Data Imported --- %s seconds ---" % (time.time() - start_time))
            self.tabWidget.setCurrentIndex(1)
            if self.check_auto_process.isChecked():
                self.process_data()
        except Exception as e:

            print("Loading Error:")
            print(e)
                
                
            # %% Position Idenitfication
    def process_data(self):
        try:
            start_time = time.time()
            frames= self.frames
            self.f_skip= self.frame_skip.value()
            sf_max=self.sf_max.value()*self.ss.value()
            sf_min= self.sf_min.value()*self.ss.value()


            self.events = pd.DataFrame(
                columns=["Start Frame", "End Frame", "Team", "Event Name","File Name"]
            )
            self.events_last = pd.DataFrame(
                columns=["Start Frame", "End Frame", "Team", "Event Name","File Name"]
            )
            self.event_flag=1
            #Home position ranks. Starting from the defense and working forward.
            #If there are only three ranks, the fourth must be the empty one.

            self.home_rank1=ast.literal_eval(self.home_rank1_inp.text())

            self.home_rank2=ast.literal_eval(self.home_rank2_inp.text())
            self.home_rank3=ast.literal_eval(self.home_rank3_inp.text())
            self.home_rank4=ast.literal_eval(self.home_rank4_inp.text())
            #Away position ranks. Starting from the defense and working forward.
            #If there are only three ranks, the fourth must be the empty one.
            self.away_rank1=ast.literal_eval(self.away_rank1_inp.text())
            self.away_rank2=ast.literal_eval(self.away_rank2_inp.text())
            self.away_rank3=ast.literal_eval(self.away_rank3_inp.text())
            self.away_rank4=ast.literal_eval(self.away_rank4_inp.text())
 


            self.bool_rectangle=False
            self.bool_centroids=False
            self.bool_convex=False
            self.bool_voronoi=False
            self.bool_dot=False
            self.bool_dist=False
            self.bool_team_centroid=False
 
            #Find the goal keepers (and eliminate them)
            (self.home_track_X_ngk,self.home_track_Y_ngk,self.home_track_name_ngk,self.away_track_X_ngk,
             self.away_track_Y_ngk,self.away_track_name_ngk,self.home_centroid_ngk,self.away_centroid_ngk,
             self.cent_dist)=find_gk(self.home_roster, self.home_track_jersey,self.home_track_X,self.home_track_Y, 
                                self.home_track_name,self.away_roster, self.away_track_jersey,
                               self.away_track_X,self.away_track_Y, self.away_track_name)



            # %% Plotting Calculations
            #Calculations for the rectangle plot
            (self.home_rect, self.away_rect)=rect_calcs(self.home_track_X_ngk,self.home_track_Y_ngk,
                                                        self.away_track_X_ngk,self.away_track_Y_ngk)


            #Calculations for the convex_plot
            (self.home_hull_vertices, self.away_hull_vertices, self.home_hull_volume,
             self.away_hull_volume)=convex_calcs(frames,self.home_track_X_ngk,self.home_track_Y_ngk,
                                            self.away_track_X_ngk,self.away_track_Y_ngk)  

            #Perfomrs the calulcations to enable the ball to change size                                
            self.sf=ball_z(sf_max,sf_min,self.ball_track_Z)

            #Centroid calculations
            (self.home_track_X_r1, self.home_track_X_r2,self.home_track_X_r3,self.home_track_X_r4,
             self.home_track_Y_r1, self.home_track_Y_r2,self.home_track_Y_r3,self.home_track_Y_r4,
             self.away_track_X_r1, self.away_track_X_r2,self.away_track_X_r3,self.away_track_X_r4,
             self.away_track_Y_r1, self.away_track_Y_r2,self.away_track_Y_r3,self.away_track_Y_r4,
             self.home_centroids,self.away_centroids,self.home_cent_dist,
             self.away_cent_dist)=find_cent(self.home_rank1,self.home_rank2,self.home_rank3,self.home_rank4,self.home_track_X,
                                       self.home_track_Y,self.home_roster,self.home_track_jersey,self.away_rank1,self.away_rank2,
                                       self.away_rank3,self.away_rank4,self.away_track_X,self.away_track_Y,self.away_roster,
                                       self.away_track_jersey)

            # Voronoi Calculations
            (self.vor_areas,self.vor_list)=voronoi_calc(self.pitch_dim,frames,self.home_track_X,self.home_track_Y,self.away_track_X,
                            self.away_track_Y)

            if self.timer is None:
                from PySide6.QtCore import QTimer
            
                self.timer = QTimer()
                self.timer.timeout.connect(self.next_frame)

            self.current_frame = 0
            print("Data Processed --- %s seconds ---" % (time.time() - start_time))
            self.tabWidget.setCurrentIndex(2)
        except Exception as e:

            print("="*50)
            print("ERROR TYPE:")
            print(type(e))
            print("="*50)
        
            print("ERROR VALUE:")
            print(e)
            print("="*50)
        
            traceback.print_exc()
            
        self.plot_frame(0)     
        
    def plot_frame(self, i):
        
        
        start_time = time.time()

        #Config Inputs
        bool_generic_colours=self.check_generic_colours.isChecked()
        bool_pitch_colour=self.check_generic_colours.isChecked()
        bool_cum_dist=self.check_cum_dist.isChecked()
        bool_speed=self.check_speed.isChecked()
        bool_axis_label=self.check_axis_labels.isChecked()
        bool_flip_ends=self.check_flip_ends.isChecked()
        bool_player_name=self.check_player_name.isChecked()
        bool_player_surname_only=self.check_player_surname_only.isChecked()
        bool_ball=self.check_ball.isChecked()
        bool_centroids_connector=self.check_centroids_connector.isChecked()
        bool_centroids_home=self.check_centroids_home.isChecked()
        bool_centroids_away=self.check_centroids_away.isChecked()
        bool_voronoi_colour=self.check_voronoi_colour.isChecked()
        bool_highlight_player=self.check_highlight_players.isChecked()
        bool_dist_home=self.check_dist_home.isChecked()
        bool_dist_away=self.check_dist_away.isChecked()
        bool_dist_comp_home=self.check_dist_comp_home.isChecked()
        bool_dist_comp_away=self.check_dist_comp_away.isChecked()
        bool_dots_home=self.check_dots_home.isChecked()
        bool_dots_away=self.check_dots_away.isChecked()
        bool_dots_ps=self.check_dots_per_second.isChecked()
        bool_dots_per_pos=self.check_dots_per_pos.isChecked()
        bool_dist_disp=True
        bool_dist_line=True
        frames= self.frames

        
        if self.bool_voronoi:
            players_selected=[]
            if self.hp1.isChecked():
                players_selected.append('0')
            if self.hp2.isChecked():
                players_selected.append('1')
            if self.hp3.isChecked():
                players_selected.append('2')            
            if self.hp4.isChecked():
                players_selected.append('3')        
            if self.hp5.isChecked():
                players_selected.append('4')        
            if self.hp6.isChecked():
                players_selected.append('5')        
            if self.hp7.isChecked():
                players_selected.append('6')
            if self.hp8.isChecked():
                players_selected.append('7')
            if self.hp9.isChecked():
                players_selected.append('8')
            if self.hp10.isChecked():
                players_selected.append('9')
            if self.hp11.isChecked():
                players_selected.append('10')
            if self.ap1.isChecked():
                players_selected.append('11')
            if self.ap2.isChecked():
                players_selected.append('12')
            if self.ap3.isChecked():
                players_selected.append('13')            
            if self.ap4.isChecked():
                players_selected.append('14')        
            if self.ap5.isChecked():
                players_selected.append('15')        
            if self.ap6.isChecked():
                players_selected.append('16')        
            if self.ap7.isChecked():
                players_selected.append('17')
            if self.ap8.isChecked():
                players_selected.append('18')
            if self.ap9.isChecked():
                players_selected.append('19')
            if self.ap10.isChecked():
                players_selected.append('20')
            if self.ap11.isChecked():
                players_selected.append('21')
            voronoi_players=players_selected
        
        if self.bool_dot:
            players_selected=[]
            if bool_dots_home:
                if self.hp1.isChecked():
                    players_selected.append('0')
                if self.hp2.isChecked():
                    players_selected.append('1')
                if self.hp3.isChecked():
                    players_selected.append('2')            
                if self.hp4.isChecked():
                    players_selected.append('3')        
                if self.hp5.isChecked():
                    players_selected.append('4')        
                if self.hp6.isChecked():
                    players_selected.append('5')        
                if self.hp7.isChecked():
                    players_selected.append('6')
                if self.hp8.isChecked():
                    players_selected.append('7')
                if self.hp9.isChecked():
                    players_selected.append('8')
                if self.hp10.isChecked():
                    players_selected.append('9')
                if self.hp11.isChecked():
                    players_selected.append('10')
            elif bool_dots_away:
                if self.ap1.isChecked():
                    players_selected.append('0')
                if self.ap2.isChecked():
                    players_selected.append('1')
                if self.ap3.isChecked():
                    players_selected.append('2')            
                if self.ap4.isChecked():
                    players_selected.append('3')        
                if self.ap5.isChecked():
                    players_selected.append('4')        
                if self.ap6.isChecked():
                    players_selected.append('5')        
                if self.ap7.isChecked():
                    players_selected.append('6')
                if self.ap8.isChecked():
                    players_selected.append('7')
                if self.ap9.isChecked():
                    players_selected.append('8')
                if self.ap10.isChecked():
                    players_selected.append('9')
                if self.ap11.isChecked():
                    players_selected.append('10')
            self.dots_players=players_selected
            

        contrast_colours=ast.literal_eval(self.contrast_colours.toPlainText())
        pitch_colour=ast.literal_eval(self.pitch_colour.text())
        dot_colours=ast.literal_eval(self.dot_colours.toPlainText())
        
        fs=self.fs.value()
        ss=self.ss.value()
        lw=self.lw.value()
        dots_per_position=self.dots_per_position.value()
        dots_per_second=self.dots_per_second.value()
        dist_player=self.dist_player.value()

        cs_sf=self.cs_sf.value()
        cs=ss*cs_sf #Centroid plot - larger because there is less going on
        ld=1.2*np.sqrt(ss)/3.14 
        
        frames=int(frames)
        
        
        bool_scatter=True

        if self.bool_centroids:
            bool_cum_dist=False
            bool_speed=False 
            bool_player_name=False
            bool_scatter=False

        # We don't want overlap with the areas
        if self.bool_voronoi or self.bool_dist or self.bool_team_centroid:
            bool_cum_dist=False
            bool_speed=False 
            
        if self.bool_dot:
            bool_cum_dist=False
            bool_speed=False 
            bool_player_name=False
            bool_scatter=False
            bool_ball=False
            
        if self.bool_team_centroid:
            bool_scatter=False
            
        #Create the translation matrix to flip
        if bool_flip_ends:
            t=-1
        else:
            t=1


        if bool_generic_colours:
            player_colours=contrast_colours
        else:
            player_colours=[self.home_data.iloc[0,2],self.home_data.iloc[0,3],self.away_data.iloc[0,2],self.away_data.iloc[0,3]]
            
        
        self.figure.clear()
        
        ax = self.figure.add_subplot(111)
        
        pitch = Pitch( pitch_type='skillcorner',pitch_length=105, pitch_width=68)

        pitch.draw(ax=ax)

        # pitch = Pitch(pitch_type='skillcorner', pitch_length=105, pitch_width=68,label=bool_axis_label,corner_arcs=True)
        # fig, ax = pitch.draw()

        #Set pitch colour
        if bool_pitch_colour:
            ax.set_facecolor((pitch_colour))

        ## Player location
        if bool_scatter:
            scatter(ax,pitch,t,ss,ld,fs,self.sf[i],player_colours,self.home_track_X[i,:],self.home_track_Y[i,:],
             self.home_track_name[i,:],self.away_track_X[i,:],self.away_track_Y[i,:],self.away_track_name[i,:],self.ball_track_X[i,:],
             self.ball_track_Y[i,:],bool_player_surname_only,bool_player_name,
             self.bool_team_centroid,bool_ball)

        ## Distance and speed
        if bool_cum_dist or bool_speed:
            plot_distance_and_speed(ax,t,ld,fs,self.home_track_X[i,:],self.home_track_Y[i,:],self.away_track_X[i,:],
                self.away_track_Y[i,:],self.ball_track_X[i,:],self.ball_track_Y[i,:],self.home_track_dist_cum[i,:],self.away_track_dist_cum[i,:],
                self.ball_track_dist_cum[i,:],self.home_track_speed[i,:],self.away_track_speed[i,:],self.ball_track_speed[i,:],
                bool_cum_dist,bool_speed)

        #Rectangle plot
        if self.bool_rectangle:
            plot_rectangles(t,self. home_rect[i,:], self.away_rect[i,:], ax, contrast_colours, fs, self.bool_rectangle)
            
        #Centroids plot
        if self.bool_centroids:
            plot_centroids(i,t, ax, fs, ss, cs,
                    self.bool_centroids, bool_centroids_home, bool_centroids_away, bool_centroids_connector,
                    self.home_track_X_r1[i,:], self.home_track_X_r2[i,:], self.home_track_X_r3[i,:], self.home_track_X_r4,
                    self.home_track_Y_r1[i,:], self.home_track_Y_r2[i,:], self.home_track_Y_r3[i,:], self.home_track_Y_r4,
                    self.away_track_X_r1[i,:], self.away_track_X_r2[i,:], self.away_track_X_r3[i,:], self.away_track_X_r4,
                    self.away_track_Y_r1[i,:], self.away_track_Y_r2[i,:], self.away_track_Y_r3[i,:],self.away_track_Y_r4,
                    self.home_centroids[i,:], self.away_centroids[i,:],self.home_cent_dist[i,:],self. away_cent_dist[i,:],
                    self.home_rank4, self.away_rank4,dot_colours)

        #Plot the convex hull
        if self.bool_convex:
            plot_convex_hulls(t, ax, fs,self.bool_convex,self.home_hull_vertices[i], self.away_hull_vertices[i],
                    self.home_track_X_ngk[i,:], self.home_track_Y_ngk[i,:],self.away_track_X_ngk[i,:],self.away_track_Y_ngk[i,:],
                    self.home_hull_volume[i], self.away_hull_volume[i], player_colours)
        #Voronoi
        if self.bool_voronoi:
            plot_voronoi(t, ax, fs, ld,self.bool_voronoi, bool_voronoi_colour, bool_highlight_player,
                    self.vor_list[i], self.vor_areas[i],self.home_track_X[i,:], self.home_track_Y[i,:],self.away_track_X[i,:],self.away_track_Y[i,:],
                    self.pitch_dim,contrast_colours, voronoi_players)
        
        #Distacnces between players
        if self.bool_dist:
            plot_distances(t, ax, fs, ld, lw, self.bool_dist, bool_dist_home, bool_dist_comp_home, 
                               bool_dist_comp_away, bool_dist_line, bool_dist_disp, dist_player,
                               self.home_track_X[i,:], self.home_track_Y[i,:], self.away_track_X[i,:], self.away_track_Y[i,:])
        #Plot team centroids
        if self.bool_team_centroid:
            plot_team_centroids(t, ax, fs, ld, ss, cs, self.bool_team_centroid, bool_player_name, 
                                    bool_centroids_connector,self.home_track_X_ngk[i,:],self. home_track_Y_ngk[i,:],
                                    self.away_track_X_ngk[i,:], self.away_track_Y_ngk[i,:], self.home_centroid_ngk[i],
                                    self.away_centroid_ngk[i], self.home_track_name_ngk[i,:], self.away_track_name_ngk[i,:],
                                    self.cent_dist[i], player_colours,bool_player_surname_only)

        #End of loop
        if self.bool_dot:
            plot_dots(ax, t, fs, ss, ld,self.bool_dot, bool_dots_ps,dots_per_position, dots_per_second,
                    self.game_time, frames,self.dots_players,bool_dots_home,self.home_track_X, self.home_track_Y, self.home_track_jersey,
                    self.away_track_X, self.away_track_Y, self.away_track_jersey,self.home_centroid_ngk, self.away_centroid_ngk,
                    self.home_roster,dot_colours)
        

        ax.set_title(self.home_data.iloc[0,0]+" vs "+self.away_data.iloc[0,0])
        ax.set_xlabel('X Position (m)')
        ax.set_ylabel('Y Position (m)')
        ax.set_xlim(pitch.dim.left, pitch.dim.right)
        ax.set_ylim(pitch.dim.bottom, pitch.dim.top)
        self.canvas.draw()     
        
        self.FrameInput.setText(str(i))
        self.TimeInput.setText(str(round(self.game_time[i],5)))
            
    def set_plot_type(self, plot_type):

        # Reset all plot modes
        self.bool_rectangle = False
        self.bool_convex = False
        self.bool_voronoi = False
        self.bool_dist = False
        self.bool_dot = False
        self.bool_team_centroid = False
        self.bool_centroids = False
    
        # Activate selected mode
        setattr(self, plot_type, True)
    
        if plot_type == "bool_dot":
            if self.timer is not None and self.timer.isActive():
                self.timer.stop()
                self.Play.setText("Play")
                self.plot_frame(0)


    def next_frame(self):
    
        self.current_frame += int(1+self.f_skip)
    
        if self.current_frame >= len(self.game_time):
    
            self.timer.stop()
            self.Play.setText("Play")
            self.current_frame = len(self.game_time) - 1
            return
    
        self.horizontalSlider.setValue(self.current_frame)
        
    def toggle_play(self):
    
        if not self.data_loaded:
            return
    
        if self.timer.isActive():
    
            self.timer.stop()
            self.Play.setText("Play")
    
        else:
    
            interval = int(1000 * self.avg_diff)
            self.timer.start(interval)
            self.Play.setText("Pause")
    def slider_changed(self, value):

        self.current_frame = value
        self.plot_frame(value)
        
    def jump_back_15s(self):
    
        if not self.data_loaded:
            return
        target_time = self.game_time[self.current_frame] - 15
    
        # Cap at minimum
        if target_time < self.game_time[0]:
            target_time = self.game_time[0]
    
        new_frame = np.argmin(np.abs(self.game_time - target_time))
    
        self.current_frame = new_frame
        self.horizontalSlider.setValue(new_frame)
    
    
    def jump_forward_15s(self):
    
        if not self.data_loaded:
            return
    
        target_time = self.game_time[self.current_frame] + 15
    
        # Cap at maximum
        
        if target_time > self.game_time.iloc[-1]:
            target_time = self.game_time.iloc[-1]
    
        new_frame = np.argmin(np.abs(self.game_time - target_time))
    
        self.current_frame = new_frame
        self.horizontalSlider.setValue(new_frame)
        
    def toggle_inputs(self, checked):
    
        if checked==False:
            self.frames_inp.setEnabled(True)
            self.game_id.setEnabled(True)
            self.check_load_all.setEnabled(True)
            self.event_load_name.setEnabled(False)
        else:
            self.frames_inp.setEnabled(False)
            self.game_id.setEnabled(False)
            self.check_load_all.setEnabled(False)
            self.event_load_name.setEnabled(True)
            
    def assign_start_frame(self):
        self.start_frame.setText(str(self.current_frame))
        self.first_frame.setValue(self.current_frame)

    def assign_end_frame(self):
        self.end_frame.setText(str(self.current_frame))
        self.last_frame.setValue(self.current_frame)
        
    def rec_tab_data(self):
        
        os.makedirs("User Defined Events", exist_ok=True)
        os.makedirs("User Defined Events\\"+str(self.game_id.value()), exist_ok=True)

        frame1=self.start_frame.text()
        frame2=self.end_frame.text()
        event_name=self.event_commit_name.text()

        # Keep rows from frame1 to frame2 inclusive
        raw_subset = self.raw.iloc[int(frame1):int(frame2) + 1]
        
        file_name="User Defined Events\\"+str(self.game_id.value())+"\\"+str(self.game_id.value())+event_name
        
        #if os.path.exists(file_name+"_"+str(self.event_flag)+".jsonl"):
        #    print("Automatically Indexing Upwards")
        #    self.event_flag+=1
        #    file_name+="_"+str(self.event_flag)
        #else:
        #    file_name+="_"+str(self.event_flag)
        #    
        
        flag = 1

        while os.path.exists(f"{file_name}_{flag}.jsonl"):
            flag += 1

        file_name = f"{file_name}_{flag}"
        
        # Save to new JSON file
        raw_subset.to_json(file_name+".jsonl", orient="records",lines=True)

        if self.check_home_event.isChecked():
            team="home"
        else: 
            team="away"

        
        self.events.loc[len(self.events)] = [frame1, frame2, team,event_name,file_name]
        
        print(self.events)

        self.events_last.loc[0]=[frame1, frame2, team,event_name,file_name]

        filename="User Defined Events\\"+str(self.game_id.value())+"\\"+str(self.game_id.value())+"User_Defined_Events.csv"
        self.events_last.to_csv(filename, index=False,mode='a', header=not os.path.exists(filename))
        
    def update_frames(self):
        if self.check_load_all.isChecked():
            self.frames_inp.setValue(self.n_frames)
        else:
            self.frames_inp.setValue(100)  
        
    def record_data(self):
        start_time = time.time()
        frames_list = []
        os.makedirs("frames", exist_ok=True)
        #Config Inputs
        bool_generic_colours=self.check_generic_colours.isChecked()
        bool_pitch_colour=self.check_generic_colours.isChecked()
        bool_cum_dist=self.check_cum_dist.isChecked()
        bool_speed=self.check_speed.isChecked()
        bool_axis_label=self.check_axis_labels.isChecked()
        bool_flip_ends=self.check_flip_ends.isChecked()
        bool_player_name=self.check_player_name.isChecked()
        bool_player_surname_only=self.check_player_surname_only.isChecked()
        bool_ball=self.check_ball.isChecked()
        bool_centroids_connector=self.check_centroids_connector.isChecked()
        bool_centroids_home=self.check_centroids_home.isChecked()
        bool_centroids_away=self.check_centroids_away.isChecked()
        bool_voronoi_colour=self.check_voronoi_colour.isChecked()
        bool_highlight_player=self.check_highlight_players.isChecked()
        bool_dist_home=self.check_dist_home.isChecked()
        bool_dist_away=self.check_dist_away.isChecked()
        bool_dist_comp_home=self.check_dist_comp_home.isChecked()
        bool_dist_comp_away=self.check_dist_comp_away.isChecked()
        bool_dots_home=self.check_dots_home.isChecked()
        bool_dots_away=self.check_dots_away.isChecked()
        bool_dots_ps=self.check_dots_per_second.isChecked()
        bool_dots_per_pos=self.check_dots_per_pos.isChecked()
        bool_dist_disp=True
        bool_dist_line=True
        frames= self.frames
        start_rec=self.first_frame.value()
        end_rec=self.last_frame.value()
        dpi_inp=self.pb_speed_2.value()
        pb_speed=self.pb_speed.value()

        for i in range(start_rec,end_rec):
            if self.bool_voronoi:
                players_selected=[]
                if self.hp1.isChecked():
                    players_selected.append('0')
                if self.hp2.isChecked():
                    players_selected.append('1')
                if self.hp3.isChecked():
                    players_selected.append('2')            
                if self.hp4.isChecked():
                    players_selected.append('3')        
                if self.hp5.isChecked():
                    players_selected.append('4')        
                if self.hp6.isChecked():
                    players_selected.append('5')        
                if self.hp7.isChecked():
                    players_selected.append('6')
                if self.hp8.isChecked():
                    players_selected.append('7')
                if self.hp9.isChecked():
                    players_selected.append('8')
                if self.hp10.isChecked():
                    players_selected.append('9')
                if self.hp11.isChecked():
                    players_selected.append('10')
                if self.ap1.isChecked():
                    players_selected.append('11')
                if self.ap2.isChecked():
                    players_selected.append('12')
                if self.ap3.isChecked():
                    players_selected.append('13')            
                if self.ap4.isChecked():
                    players_selected.append('14')        
                if self.ap5.isChecked():
                    players_selected.append('15')        
                if self.ap6.isChecked():
                    players_selected.append('16')        
                if self.ap7.isChecked():
                    players_selected.append('17')
                if self.ap8.isChecked():
                    players_selected.append('18')
                if self.ap9.isChecked():
                    players_selected.append('19')
                if self.ap10.isChecked():
                    players_selected.append('20')
                if self.ap11.isChecked():
                    players_selected.append('21')
                voronoi_players=players_selected
            
            if self.bool_dot:
                players_selected=[]
                if bool_dots_home:
                    if self.hp1.isChecked():
                        players_selected.append('0')
                    if self.hp2.isChecked():
                        players_selected.append('1')
                    if self.hp3.isChecked():
                        players_selected.append('2')            
                    if self.hp4.isChecked():
                        players_selected.append('3')        
                    if self.hp5.isChecked():
                        players_selected.append('4')        
                    if self.hp6.isChecked():
                        players_selected.append('5')        
                    if self.hp7.isChecked():
                        players_selected.append('6')
                    if self.hp8.isChecked():
                        players_selected.append('7')
                    if self.hp9.isChecked():
                        players_selected.append('8')
                    if self.hp10.isChecked():
                        players_selected.append('9')
                    if self.hp11.isChecked():
                        players_selected.append('10')
                elif bool_dots_away:
                    if self.ap1.isChecked():
                        players_selected.append('0')
                    if self.ap2.isChecked():
                        players_selected.append('1')
                    if self.ap3.isChecked():
                        players_selected.append('2')            
                    if self.ap4.isChecked():
                        players_selected.append('3')        
                    if self.ap5.isChecked():
                        players_selected.append('4')        
                    if self.ap6.isChecked():
                        players_selected.append('5')        
                    if self.ap7.isChecked():
                        players_selected.append('6')
                    if self.ap8.isChecked():
                        players_selected.append('7')
                    if self.ap9.isChecked():
                        players_selected.append('8')
                    if self.ap10.isChecked():
                        players_selected.append('9')
                    if self.ap11.isChecked():
                        players_selected.append('10')
                self.dots_players=players_selected
    
            contrast_colours=ast.literal_eval(self.contrast_colours.toPlainText())
            pitch_colour=ast.literal_eval(self.pitch_colour.text())
            dot_colours=ast.literal_eval(self.dot_colours.toPlainText())
            
            recording_name=self.recording_name.text()

            
            fs=self.fs.value()
            ss=self.ss.value()
            lw=self.lw.value()
            dots_per_position=self.dots_per_position.value()
            dots_per_second=self.dots_per_second.value()
            dist_player=self.dist_player.value()
    
            cs_sf=self.cs_sf.value()
            cs=ss*cs_sf #Centroid plot - larger because there is less going on
            ld=1.2*np.sqrt(ss)/3.14 
            
            frames=int(frames)
            
            
            bool_scatter=True
    
            if self.bool_centroids:
                bool_cum_dist=False
                bool_speed=False 
                bool_player_name=False
                bool_scatter=False
    
            # We don't want overlap with the areas
            if self.bool_voronoi or self.bool_dist or self.bool_team_centroid:
                bool_cum_dist=False
                bool_speed=False 
                
            if self.bool_dot:
                bool_cum_dist=False
                bool_speed=False 
                bool_player_name=False
                bool_scatter=False
                bool_ball=False
                
            if self.bool_team_centroid:
                bool_scatter=False
                
            #Create the translation matrix to flip
            if bool_flip_ends:
                t=-1
            else:
                t=1
    
    
            if bool_generic_colours:
                player_colours=contrast_colours
            else:
                player_colours=[self.home_data.iloc[0,2],self.home_data.iloc[0,3],self.away_data.iloc[0,2],self.away_data.iloc[0,3]]
                
            pitch = Pitch(pitch_type='skillcorner', pitch_length=105, pitch_width=68,label=bool_axis_label,corner_arcs=True)
            fig, ax = pitch.draw()
            
            
            # pitch = Pitch( pitch_type='skillcorner',pitch_length=105, pitch_width=68)
    
            # pitch.draw(ax=ax)
    
            # pitch = Pitch(pitch_type='skillcorner', pitch_length=105, pitch_width=68,label=bool_axis_label,corner_arcs=True)
            # fig, ax = pitch.draw()
    
            #Set pitch colour
            if bool_pitch_colour:
                ax.set_facecolor((pitch_colour))
    
            ## Player location
            if bool_scatter:
                scatter(ax,pitch,t,ss,ld,fs,self.sf[i],player_colours,self.home_track_X[i,:],self.home_track_Y[i,:],
                 self.home_track_name[i,:],self.away_track_X[i,:],self.away_track_Y[i,:],self.away_track_name[i,:],self.ball_track_X[i,:],
                 self.ball_track_Y[i,:],bool_player_surname_only,bool_player_name,
                 self.bool_team_centroid,bool_ball)
    
            ## Distance and speed
            if bool_cum_dist or bool_speed:
                plot_distance_and_speed(ax,t,ld,fs,self.home_track_X[i,:],self.home_track_Y[i,:],self.away_track_X[i,:],
                    self.away_track_Y[i,:],self.ball_track_X[i,:],self.ball_track_Y[i,:],self.home_track_dist_cum[i,:],self.away_track_dist_cum[i,:],
                    self.ball_track_dist_cum[i,:],self.home_track_speed[i,:],self.away_track_speed[i,:],self.ball_track_speed[i,:],
                    bool_cum_dist,bool_speed)
    
            #Rectangle plot
            if self.bool_rectangle:
                plot_rectangles(t,self. home_rect[i,:], self.away_rect[i,:], ax, contrast_colours, fs, self.bool_rectangle)
                
            #Centroids plot
            if self.bool_centroids:
                plot_centroids(i,t, ax, fs, ss, cs,
                        self.bool_centroids, bool_centroids_home, bool_centroids_away, bool_centroids_connector,
                        self.home_track_X_r1[i,:], self.home_track_X_r2[i,:], self.home_track_X_r3[i,:], self.home_track_X_r4,
                        self.home_track_Y_r1[i,:], self.home_track_Y_r2[i,:], self.home_track_Y_r3[i,:], self.home_track_Y_r4,
                        self.away_track_X_r1[i,:], self.away_track_X_r2[i,:], self.away_track_X_r3[i,:], self.away_track_X_r4,
                        self.away_track_Y_r1[i,:], self.away_track_Y_r2[i,:], self.away_track_Y_r3[i,:],self.away_track_Y_r4,
                        self.home_centroids[i,:], self.away_centroids[i,:],self.home_cent_dist[i,:],self. away_cent_dist[i,:],
                        self.home_rank4, self.away_rank4,dot_colours)
    
            #Plot the convex hull
            if self.bool_convex:
                plot_convex_hulls(t, ax, fs,self.bool_convex,self.home_hull_vertices[i], self.away_hull_vertices[i],
                        self.home_track_X_ngk[i,:], self.home_track_Y_ngk[i,:],self.away_track_X_ngk[i,:],self.away_track_Y_ngk[i,:],
                        self.home_hull_volume[i], self.away_hull_volume[i], player_colours)
            #Voronoi
            if self.bool_voronoi:
                plot_voronoi(t, ax, fs, ld,self.bool_voronoi, bool_voronoi_colour, bool_highlight_player,
                        self.vor_list[i], self.vor_areas[i],self.home_track_X[i,:], self.home_track_Y[i,:],self.away_track_X[i,:],self.away_track_Y[i,:],
                        self.pitch_dim,contrast_colours, voronoi_players)
            
            #Distacnces between players
            if self.bool_dist:
                plot_distances(t, ax, fs, ld, lw, self.bool_dist, bool_dist_home, bool_dist_comp_home, 
                                   bool_dist_comp_away, bool_dist_line, bool_dist_disp, dist_player,
                                   self.home_track_X[i,:], self.home_track_Y[i,:], self.away_track_X[i,:], self.away_track_Y[i,:])
            #Plot team centroids
            if self.bool_team_centroid:
                plot_team_centroids(t, ax, fs, ld, ss, cs, self.bool_team_centroid, bool_player_name, 
                                        bool_centroids_connector,self.home_track_X_ngk[i,:],self. home_track_Y_ngk[i,:],
                                        self.away_track_X_ngk[i,:], self.away_track_Y_ngk[i,:], self.home_centroid_ngk[i],
                                        self.away_centroid_ngk[i], self.home_track_name_ngk[i,:], self.away_track_name_ngk[i,:],
                                        self.cent_dist[i], player_colours,bool_player_surname_only)
    
            #End of loop
            if self.bool_dot:
                plot_dots(ax, t, fs, ss, ld,self.bool_dot, bool_dots_ps,dots_per_position, dots_per_second,
                        self.game_time, frames,self.dots_players,bool_dots_home,self.home_track_X, self.home_track_Y, self.home_track_jersey,
                        self.away_track_X, self.away_track_Y, self.away_track_jersey,self.home_centroid_ngk, self.away_centroid_ngk,
                        self.home_roster,dot_colours)
            
    
            ax.set_title(self.home_data.iloc[0,0]+" vs "+self.away_data.iloc[0,0])
            ax.set_xlabel('X Position (m)')
            ax.set_ylabel('Y Position (m)')
            ax.set_xlim(pitch.dim.left, pitch.dim.right)
            ax.set_ylim(pitch.dim.bottom, pitch.dim.top)
            #Saving figures
            plt.savefig(f"frames/frame_{i:04d}.png", dpi=dpi_inp)
            plt.clf()
            plt.close()
        
            frames_list.append(imageio.imread(f"frames/frame_{i:04d}.png"))
        #imageio.mimsave("match_animation.gif", frames_list, duration=0.05)
        # Read first frame to get size
        first_frame = imageio.imread(f"frames/frame_{start_rec:04d}.png")
        height, width, _ = first_frame.shape
        
        # Create MP4 writer (H.264 baseline)
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")   # Windows-friendly codec
        video = cv2.VideoWriter(recording_name+".mp4", fourcc, pb_speed*1/self.avg_diff, (width, height))
        
        # Write frames
        for i in range(start_rec,end_rec):
            frame = imageio.imread(f"frames/frame_{i:04d}.png")
            frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
            video.write(frame_bgr)
        
        video.release()
        shutil.rmtree("frames", ignore_errors=True)
        os.makedirs("frames", exist_ok=True)
        print("Data Recorded --- %s seconds ---" % (time.time() - start_time))

        
            
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(699, 647)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.gridLayout = QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        self.load = QWidget()
        self.load.setObjectName(u"load")
        self.horizontalLayout_29 = QHBoxLayout(self.load)
        self.horizontalLayout_29.setObjectName(u"horizontalLayout_29")
        self.verticalLayout_18 = QVBoxLayout()
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.label_48 = QLabel(self.load)
        self.label_48.setObjectName(u"label_48")
        font = QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setUnderline(True)
        self.label_48.setFont(font)
        self.label_48.setAlignment(Qt.AlignCenter)

        self.verticalLayout_18.addWidget(self.label_48)

        self.label_49 = QLabel(self.load)
        self.label_49.setObjectName(u"label_49")
        self.label_49.setAlignment(Qt.AlignCenter)

        self.verticalLayout_18.addWidget(self.label_49)

        self.label_50 = QLabel(self.load)
        self.label_50.setObjectName(u"label_50")
        font1 = QFont()
        font1.setPointSize(10)
        font1.setBold(True)
        font1.setUnderline(True)
        self.label_50.setFont(font1)
        self.label_50.setAlignment(Qt.AlignCenter)

        self.verticalLayout_18.addWidget(self.label_50)

        self.label_51 = QLabel(self.load)
        self.label_51.setObjectName(u"label_51")
        self.label_51.setWordWrap(True)

        self.verticalLayout_18.addWidget(self.label_51)

        self.check_load_event = QCheckBox(self.load)
        self.check_load_event.setObjectName(u"check_load_event")

        self.verticalLayout_18.addWidget(self.check_load_event)

        self.event_load_name = QLineEdit(self.load)
        self.event_load_name.setObjectName(u"event_load_name")
        self.event_load_name.setMaximumSize(QSize(200, 16777215))

        self.verticalLayout_18.addWidget(self.event_load_name)

        self.label_52 = QLabel(self.load)
        self.label_52.setObjectName(u"label_52")
        self.label_52.setFont(font1)
        self.label_52.setAlignment(Qt.AlignCenter)

        self.verticalLayout_18.addWidget(self.label_52)

        self.horizontalLayout_15 = QHBoxLayout()
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.label_23 = QLabel(self.load)
        self.label_23.setObjectName(u"label_23")

        self.horizontalLayout_15.addWidget(self.label_23)

        self.game_id = QSpinBox(self.load)
        self.game_id.setObjectName(u"game_id")
        self.game_id.setMaximum(100000)
        self.game_id.setValue(10513)

        self.horizontalLayout_15.addWidget(self.game_id)


        self.verticalLayout_18.addLayout(self.horizontalLayout_15)

        self.check_load_all = QCheckBox(self.load)
        self.check_load_all.setObjectName(u"check_load_all")

        self.verticalLayout_18.addWidget(self.check_load_all)

        self.horizontalLayout_16 = QHBoxLayout()
        self.horizontalLayout_16.setObjectName(u"horizontalLayout_16")
        self.label_24 = QLabel(self.load)
        self.label_24.setObjectName(u"label_24")

        self.horizontalLayout_16.addWidget(self.label_24)

        self.frames_inp = QSpinBox(self.load)
        self.frames_inp.setObjectName(u"frames_inp")
        self.frames_inp.setMaximum(1000000)
        self.frames_inp.setValue(100)

        self.horizontalLayout_16.addWidget(self.frames_inp)


        self.verticalLayout_18.addLayout(self.horizontalLayout_16)

        self.check_auto_process = QCheckBox(self.load)
        self.check_auto_process.setObjectName(u"check_auto_process")

        self.verticalLayout_18.addWidget(self.check_auto_process)

        self.btn_load_data = QPushButton(self.load)
        self.btn_load_data.setObjectName(u"btn_load_data")

        self.verticalLayout_18.addWidget(self.btn_load_data)

        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_18.addItem(self.verticalSpacer_2)


        self.horizontalLayout_29.addLayout(self.verticalLayout_18)

        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.label_13 = QLabel(self.load)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setFont(font1)
        self.label_13.setAlignment(Qt.AlignCenter)

        self.verticalLayout_6.addWidget(self.label_13)

        self.label_14 = QLabel(self.load)
        self.label_14.setObjectName(u"label_14")
        self.label_14.setAlignment(Qt.AlignCenter)
        self.label_14.setWordWrap(True)

        self.verticalLayout_6.addWidget(self.label_14)

        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.label_15 = QLabel(self.load)
        self.label_15.setObjectName(u"label_15")

        self.horizontalLayout_7.addWidget(self.label_15)

        self.home_rank1_inp = QLineEdit(self.load)
        self.home_rank1_inp.setObjectName(u"home_rank1_inp")

        self.horizontalLayout_7.addWidget(self.home_rank1_inp)


        self.verticalLayout_6.addLayout(self.horizontalLayout_7)

        self.horizontalLayout_8 = QHBoxLayout()
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.label_16 = QLabel(self.load)
        self.label_16.setObjectName(u"label_16")

        self.horizontalLayout_8.addWidget(self.label_16)

        self.home_rank2_inp = QLineEdit(self.load)
        self.home_rank2_inp.setObjectName(u"home_rank2_inp")

        self.horizontalLayout_8.addWidget(self.home_rank2_inp)


        self.verticalLayout_6.addLayout(self.horizontalLayout_8)

        self.horizontalLayout_9 = QHBoxLayout()
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.label_17 = QLabel(self.load)
        self.label_17.setObjectName(u"label_17")

        self.horizontalLayout_9.addWidget(self.label_17)

        self.home_rank3_inp = QLineEdit(self.load)
        self.home_rank3_inp.setObjectName(u"home_rank3_inp")

        self.horizontalLayout_9.addWidget(self.home_rank3_inp)


        self.verticalLayout_6.addLayout(self.horizontalLayout_9)

        self.horizontalLayout_10 = QHBoxLayout()
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.label_18 = QLabel(self.load)
        self.label_18.setObjectName(u"label_18")

        self.horizontalLayout_10.addWidget(self.label_18)

        self.home_rank4_inp = QLineEdit(self.load)
        self.home_rank4_inp.setObjectName(u"home_rank4_inp")

        self.horizontalLayout_10.addWidget(self.home_rank4_inp)


        self.verticalLayout_6.addLayout(self.horizontalLayout_10)

        self.horizontalLayout_12 = QHBoxLayout()
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.label_20 = QLabel(self.load)
        self.label_20.setObjectName(u"label_20")

        self.horizontalLayout_12.addWidget(self.label_20)

        self.away_rank1_inp = QLineEdit(self.load)
        self.away_rank1_inp.setObjectName(u"away_rank1_inp")

        self.horizontalLayout_12.addWidget(self.away_rank1_inp)


        self.verticalLayout_6.addLayout(self.horizontalLayout_12)

        self.horizontalLayout_14 = QHBoxLayout()
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.label_22 = QLabel(self.load)
        self.label_22.setObjectName(u"label_22")

        self.horizontalLayout_14.addWidget(self.label_22)

        self.away_rank2_inp = QLineEdit(self.load)
        self.away_rank2_inp.setObjectName(u"away_rank2_inp")

        self.horizontalLayout_14.addWidget(self.away_rank2_inp)


        self.verticalLayout_6.addLayout(self.horizontalLayout_14)

        self.horizontalLayout_11 = QHBoxLayout()
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.label_19 = QLabel(self.load)
        self.label_19.setObjectName(u"label_19")

        self.horizontalLayout_11.addWidget(self.label_19)

        self.away_rank3_inp = QLineEdit(self.load)
        self.away_rank3_inp.setObjectName(u"away_rank3_inp")

        self.horizontalLayout_11.addWidget(self.away_rank3_inp)


        self.verticalLayout_6.addLayout(self.horizontalLayout_11)

        self.horizontalLayout_13 = QHBoxLayout()
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.label_21 = QLabel(self.load)
        self.label_21.setObjectName(u"label_21")

        self.horizontalLayout_13.addWidget(self.label_21)

        self.away_rank4_inp = QLineEdit(self.load)
        self.away_rank4_inp.setObjectName(u"away_rank4_inp")

        self.horizontalLayout_13.addWidget(self.away_rank4_inp)


        self.verticalLayout_6.addLayout(self.horizontalLayout_13)

        self.verticalSpacer_7 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_6.addItem(self.verticalSpacer_7)


        self.horizontalLayout_29.addLayout(self.verticalLayout_6)

        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_29.addItem(self.horizontalSpacer_5)

        self.tabWidget.addTab(self.load, "")
        self.plot_config = QWidget()
        self.plot_config.setObjectName(u"plot_config")
        self.horizontalLayout_31 = QHBoxLayout(self.plot_config)
        self.horizontalLayout_31.setObjectName(u"horizontalLayout_31")
        self.verticalLayout_15 = QVBoxLayout()
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.label_3 = QLabel(self.plot_config)
        self.label_3.setObjectName(u"label_3")
        font2 = QFont()
        font2.setPointSize(10)
        font2.setBold(True)
        font2.setUnderline(True)
        font2.setKerning(True)
        self.label_3.setFont(font2)
        self.label_3.setAlignment(Qt.AlignCenter)

        self.verticalLayout_4.addWidget(self.label_3)

        self.check_player_name = QCheckBox(self.plot_config)
        self.check_player_name.setObjectName(u"check_player_name")
        self.check_player_name.setEnabled(True)
        self.check_player_name.setLayoutDirection(Qt.LeftToRight)
        self.check_player_name.setChecked(True)

        self.verticalLayout_4.addWidget(self.check_player_name)

        self.check_player_surname_only = QCheckBox(self.plot_config)
        self.check_player_surname_only.setObjectName(u"check_player_surname_only")
        self.check_player_surname_only.setLayoutDirection(Qt.LeftToRight)
        self.check_player_surname_only.setChecked(True)

        self.verticalLayout_4.addWidget(self.check_player_surname_only)

        self.check_ball = QCheckBox(self.plot_config)
        self.check_ball.setObjectName(u"check_ball")
        self.check_ball.setLayoutDirection(Qt.LeftToRight)
        self.check_ball.setChecked(True)

        self.verticalLayout_4.addWidget(self.check_ball)

        self.check_z_ball = QCheckBox(self.plot_config)
        self.check_z_ball.setObjectName(u"check_z_ball")
        self.check_z_ball.setLayoutDirection(Qt.LeftToRight)
        self.check_z_ball.setChecked(True)

        self.verticalLayout_4.addWidget(self.check_z_ball)

        self.check_axis_labels = QCheckBox(self.plot_config)
        self.check_axis_labels.setObjectName(u"check_axis_labels")
        self.check_axis_labels.setLayoutDirection(Qt.LeftToRight)

        self.verticalLayout_4.addWidget(self.check_axis_labels)

        self.check_flip_ends = QCheckBox(self.plot_config)
        self.check_flip_ends.setObjectName(u"check_flip_ends")
        self.check_flip_ends.setLayoutDirection(Qt.LeftToRight)

        self.verticalLayout_4.addWidget(self.check_flip_ends)

        self.check_generic_colours = QCheckBox(self.plot_config)
        self.check_generic_colours.setObjectName(u"check_generic_colours")
        self.check_generic_colours.setLayoutDirection(Qt.LeftToRight)

        self.verticalLayout_4.addWidget(self.check_generic_colours)

        self.check_pitch_colour = QCheckBox(self.plot_config)
        self.check_pitch_colour.setObjectName(u"check_pitch_colour")
        self.check_pitch_colour.setLayoutDirection(Qt.LeftToRight)

        self.verticalLayout_4.addWidget(self.check_pitch_colour)

        self.horizontalLayout_28 = QHBoxLayout()
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.label_47 = QLabel(self.plot_config)
        self.label_47.setObjectName(u"label_47")

        self.horizontalLayout_28.addWidget(self.label_47)

        self.frame_skip = QSpinBox(self.plot_config)
        self.frame_skip.setObjectName(u"frame_skip")
        self.frame_skip.setMinimum(0)
        self.frame_skip.setMaximum(100)
        self.frame_skip.setValue(0)

        self.horizontalLayout_28.addWidget(self.frame_skip)


        self.verticalLayout_4.addLayout(self.horizontalLayout_28)

        self.label_4 = QLabel(self.plot_config)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setFont(font1)
        self.label_4.setAlignment(Qt.AlignCenter)

        self.verticalLayout_4.addWidget(self.label_4)

        self.check_cum_dist = QCheckBox(self.plot_config)
        self.check_cum_dist.setObjectName(u"check_cum_dist")

        self.verticalLayout_4.addWidget(self.check_cum_dist)

        self.check_speed = QCheckBox(self.plot_config)
        self.check_speed.setObjectName(u"check_speed")

        self.verticalLayout_4.addWidget(self.check_speed)


        self.verticalLayout_15.addLayout(self.verticalLayout_4)

        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.label_12 = QLabel(self.plot_config)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setFont(font1)
        self.label_12.setAlignment(Qt.AlignCenter)

        self.verticalLayout_5.addWidget(self.label_12)

        self.check_centroids_connector = QCheckBox(self.plot_config)
        self.check_centroids_connector.setObjectName(u"check_centroids_connector")
        self.check_centroids_connector.setChecked(True)

        self.verticalLayout_5.addWidget(self.check_centroids_connector)

        self.check_centroids_home = QCheckBox(self.plot_config)
        self.check_centroids_home.setObjectName(u"check_centroids_home")
        self.check_centroids_home.setChecked(True)

        self.verticalLayout_5.addWidget(self.check_centroids_home)

        self.check_centroids_away = QCheckBox(self.plot_config)
        self.check_centroids_away.setObjectName(u"check_centroids_away")

        self.verticalLayout_5.addWidget(self.check_centroids_away)

        self.horizontalLayout_22 = QHBoxLayout()
        self.horizontalLayout_22.setObjectName(u"horizontalLayout_22")
        self.label_34 = QLabel(self.plot_config)
        self.label_34.setObjectName(u"label_34")

        self.horizontalLayout_22.addWidget(self.label_34)

        self.cs_sf = QDoubleSpinBox(self.plot_config)
        self.cs_sf.setObjectName(u"cs_sf")
        self.cs_sf.setMinimum(0.100000000000000)
        self.cs_sf.setMaximum(100.000000000000000)
        self.cs_sf.setSingleStep(0.500000000000000)
        self.cs_sf.setValue(2.000000000000000)

        self.horizontalLayout_22.addWidget(self.cs_sf)


        self.verticalLayout_5.addLayout(self.horizontalLayout_22)


        self.verticalLayout_15.addLayout(self.verticalLayout_5)

        self.verticalLayout_12 = QVBoxLayout()
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.label_35 = QLabel(self.plot_config)
        self.label_35.setObjectName(u"label_35")
        self.label_35.setFont(font1)
        self.label_35.setAlignment(Qt.AlignCenter)

        self.verticalLayout_12.addWidget(self.label_35)

        self.check_voronoi_colour = QCheckBox(self.plot_config)
        self.check_voronoi_colour.setObjectName(u"check_voronoi_colour")
        self.check_voronoi_colour.setChecked(True)

        self.verticalLayout_12.addWidget(self.check_voronoi_colour)

        self.check_highlight_players = QCheckBox(self.plot_config)
        self.check_highlight_players.setObjectName(u"check_highlight_players")
        self.check_highlight_players.setChecked(True)

        self.verticalLayout_12.addWidget(self.check_highlight_players)

        self.verticalSpacer_6 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_12.addItem(self.verticalSpacer_6)


        self.verticalLayout_15.addLayout(self.verticalLayout_12)


        self.horizontalLayout_31.addLayout(self.verticalLayout_15)

        self.verticalLayout_16 = QVBoxLayout()
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.verticalLayout_13 = QVBoxLayout()
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.label_36 = QLabel(self.plot_config)
        self.label_36.setObjectName(u"label_36")
        self.label_36.setFont(font1)
        self.label_36.setAlignment(Qt.AlignCenter)

        self.verticalLayout_13.addWidget(self.label_36)

        self.horizontalLayout_23 = QHBoxLayout()
        self.horizontalLayout_23.setObjectName(u"horizontalLayout_23")
        self.label_37 = QLabel(self.plot_config)
        self.label_37.setObjectName(u"label_37")

        self.horizontalLayout_23.addWidget(self.label_37)

        self.fs = QSpinBox(self.plot_config)
        self.fs.setObjectName(u"fs")
        self.fs.setValue(5)

        self.horizontalLayout_23.addWidget(self.fs)


        self.verticalLayout_13.addLayout(self.horizontalLayout_23)

        self.horizontalLayout_24 = QHBoxLayout()
        self.horizontalLayout_24.setObjectName(u"horizontalLayout_24")
        self.label_38 = QLabel(self.plot_config)
        self.label_38.setObjectName(u"label_38")

        self.horizontalLayout_24.addWidget(self.label_38)

        self.ss = QSpinBox(self.plot_config)
        self.ss.setObjectName(u"ss")
        self.ss.setValue(20)

        self.horizontalLayout_24.addWidget(self.ss)


        self.verticalLayout_13.addLayout(self.horizontalLayout_24)

        self.horizontalLayout_25 = QHBoxLayout()
        self.horizontalLayout_25.setObjectName(u"horizontalLayout_25")
        self.label_39 = QLabel(self.plot_config)
        self.label_39.setObjectName(u"label_39")

        self.horizontalLayout_25.addWidget(self.label_39)

        self.sf_min = QDoubleSpinBox(self.plot_config)
        self.sf_min.setObjectName(u"sf_min")
        self.sf_min.setMinimum(1.000000000000000)
        self.sf_min.setMaximum(100.000000000000000)
        self.sf_min.setSingleStep(0.000000000000000)
        self.sf_min.setValue(2.000000000000000)

        self.horizontalLayout_25.addWidget(self.sf_min)


        self.verticalLayout_13.addLayout(self.horizontalLayout_25)

        self.horizontalLayout_26 = QHBoxLayout()
        self.horizontalLayout_26.setObjectName(u"horizontalLayout_26")
        self.label_40 = QLabel(self.plot_config)
        self.label_40.setObjectName(u"label_40")

        self.horizontalLayout_26.addWidget(self.label_40)

        self.sf_max = QDoubleSpinBox(self.plot_config)
        self.sf_max.setObjectName(u"sf_max")
        self.sf_max.setMinimum(1.000000000000000)
        self.sf_max.setMaximum(100.000000000000000)
        self.sf_max.setSingleStep(0.000000000000000)
        self.sf_max.setValue(5.000000000000000)

        self.horizontalLayout_26.addWidget(self.sf_max)


        self.verticalLayout_13.addLayout(self.horizontalLayout_26)


        self.verticalLayout_16.addLayout(self.verticalLayout_13)

        self.verticalLayout_11 = QVBoxLayout()
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.label_30 = QLabel(self.plot_config)
        self.label_30.setObjectName(u"label_30")
        self.label_30.setFont(font1)
        self.label_30.setAlignment(Qt.AlignCenter)

        self.verticalLayout_11.addWidget(self.label_30)

        self.label_31 = QLabel(self.plot_config)
        self.label_31.setObjectName(u"label_31")

        self.verticalLayout_11.addWidget(self.label_31)

        self.horizontalLayout_20 = QHBoxLayout()
        self.horizontalLayout_20.setObjectName(u"horizontalLayout_20")
        self.label_32 = QLabel(self.plot_config)
        self.label_32.setObjectName(u"label_32")

        self.horizontalLayout_20.addWidget(self.label_32)

        self.dist_player = QSpinBox(self.plot_config)
        self.dist_player.setObjectName(u"dist_player")
        self.dist_player.setMinimum(1)
        self.dist_player.setMaximum(11)

        self.horizontalLayout_20.addWidget(self.dist_player)


        self.verticalLayout_11.addLayout(self.horizontalLayout_20)

        self.horizontalLayout_21 = QHBoxLayout()
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.label_33 = QLabel(self.plot_config)
        self.label_33.setObjectName(u"label_33")

        self.horizontalLayout_21.addWidget(self.label_33)

        self.lw = QDoubleSpinBox(self.plot_config)
        self.lw.setObjectName(u"lw")
        self.lw.setMinimum(0.100000000000000)
        self.lw.setMaximum(10.000000000000000)
        self.lw.setSingleStep(0.100000000000000)
        self.lw.setValue(0.750000000000000)

        self.horizontalLayout_21.addWidget(self.lw)


        self.verticalLayout_11.addLayout(self.horizontalLayout_21)

        self.check_dist_home = QCheckBox(self.plot_config)
        self.check_dist_home.setObjectName(u"check_dist_home")
        self.check_dist_home.setChecked(True)

        self.verticalLayout_11.addWidget(self.check_dist_home)

        self.check_dist_away = QCheckBox(self.plot_config)
        self.check_dist_away.setObjectName(u"check_dist_away")

        self.verticalLayout_11.addWidget(self.check_dist_away)

        self.check_dist_comp_home = QCheckBox(self.plot_config)
        self.check_dist_comp_home.setObjectName(u"check_dist_comp_home")
        self.check_dist_comp_home.setChecked(True)

        self.verticalLayout_11.addWidget(self.check_dist_comp_home)

        self.check_dist_comp_away = QCheckBox(self.plot_config)
        self.check_dist_comp_away.setObjectName(u"check_dist_comp_away")

        self.verticalLayout_11.addWidget(self.check_dist_comp_away)


        self.verticalLayout_16.addLayout(self.verticalLayout_11)

        self.verticalLayout_7 = QVBoxLayout()
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.label_25 = QLabel(self.plot_config)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setFont(font1)
        self.label_25.setAlignment(Qt.AlignCenter)

        self.verticalLayout_7.addWidget(self.label_25)

        self.check_dots_home = QCheckBox(self.plot_config)
        self.check_dots_home.setObjectName(u"check_dots_home")
        self.check_dots_home.setChecked(True)

        self.verticalLayout_7.addWidget(self.check_dots_home)

        self.check_dots_away = QCheckBox(self.plot_config)
        self.check_dots_away.setObjectName(u"check_dots_away")

        self.verticalLayout_7.addWidget(self.check_dots_away)

        self.check_dots_per_second = QCheckBox(self.plot_config)
        self.check_dots_per_second.setObjectName(u"check_dots_per_second")

        self.verticalLayout_7.addWidget(self.check_dots_per_second)

        self.check_dots_per_pos = QCheckBox(self.plot_config)
        self.check_dots_per_pos.setObjectName(u"check_dots_per_pos")

        self.verticalLayout_7.addWidget(self.check_dots_per_pos)

        self.horizontalLayout_17 = QHBoxLayout()
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.label_26 = QLabel(self.plot_config)
        self.label_26.setObjectName(u"label_26")

        self.horizontalLayout_17.addWidget(self.label_26)

        self.dots_per_second = QDoubleSpinBox(self.plot_config)
        self.dots_per_second.setObjectName(u"dots_per_second")
        self.dots_per_second.setMaximum(1000.000000000000000)
        self.dots_per_second.setValue(1.000000000000000)

        self.horizontalLayout_17.addWidget(self.dots_per_second)


        self.verticalLayout_7.addLayout(self.horizontalLayout_17)

        self.horizontalLayout_18 = QHBoxLayout()
        self.horizontalLayout_18.setObjectName(u"horizontalLayout_18")
        self.label_27 = QLabel(self.plot_config)
        self.label_27.setObjectName(u"label_27")

        self.horizontalLayout_18.addWidget(self.label_27)

        self.dots_per_position = QSpinBox(self.plot_config)
        self.dots_per_position.setObjectName(u"dots_per_position")
        self.dots_per_position.setMinimum(1)
        self.dots_per_position.setMaximum(1000000)
        self.dots_per_position.setValue(100)

        self.horizontalLayout_18.addWidget(self.dots_per_position)


        self.verticalLayout_7.addLayout(self.horizontalLayout_18)


        self.verticalLayout_16.addLayout(self.verticalLayout_7)

        self.verticalSpacer_5 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_16.addItem(self.verticalSpacer_5)


        self.horizontalLayout_31.addLayout(self.verticalLayout_16)

        self.verticalLayout_17 = QVBoxLayout()
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.verticalLayout_14 = QVBoxLayout()
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.label_41 = QLabel(self.plot_config)
        self.label_41.setObjectName(u"label_41")
        self.label_41.setFont(font1)
        self.label_41.setAlignment(Qt.AlignCenter)

        self.verticalLayout_14.addWidget(self.label_41)

        self.horizontalLayout_27 = QHBoxLayout()
        self.horizontalLayout_27.setObjectName(u"horizontalLayout_27")
        self.label_42 = QLabel(self.plot_config)
        self.label_42.setObjectName(u"label_42")

        self.horizontalLayout_27.addWidget(self.label_42)

        self.pitch_colour = QLineEdit(self.plot_config)
        self.pitch_colour.setObjectName(u"pitch_colour")

        self.horizontalLayout_27.addWidget(self.pitch_colour)


        self.verticalLayout_14.addLayout(self.horizontalLayout_27)

        self.label_43 = QLabel(self.plot_config)
        self.label_43.setObjectName(u"label_43")

        self.verticalLayout_14.addWidget(self.label_43)

        self.contrast_colours = QTextEdit(self.plot_config)
        self.contrast_colours.setObjectName(u"contrast_colours")
        self.contrast_colours.setEnabled(True)
        self.contrast_colours.setMaximumSize(QSize(400, 30))

        self.verticalLayout_14.addWidget(self.contrast_colours)

        self.label_44 = QLabel(self.plot_config)
        self.label_44.setObjectName(u"label_44")

        self.verticalLayout_14.addWidget(self.label_44)

        self.dot_colours = QTextEdit(self.plot_config)
        self.dot_colours.setObjectName(u"dot_colours")
        self.dot_colours.setMaximumSize(QSize(400, 50))

        self.verticalLayout_14.addWidget(self.dot_colours)


        self.verticalLayout_17.addLayout(self.verticalLayout_14)

        self.verticalLayout_10 = QVBoxLayout()
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.label_28 = QLabel(self.plot_config)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setFont(font1)
        self.label_28.setAlignment(Qt.AlignCenter)

        self.verticalLayout_10.addWidget(self.label_28)

        self.label_29 = QLabel(self.plot_config)
        self.label_29.setObjectName(u"label_29")

        self.verticalLayout_10.addWidget(self.label_29)

        self.horizontalLayout_19 = QHBoxLayout()
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.verticalLayout_8 = QVBoxLayout()
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.hp1 = QCheckBox(self.plot_config)
        self.hp1.setObjectName(u"hp1")
        self.hp1.setChecked(True)

        self.verticalLayout_8.addWidget(self.hp1)

        self.hp2 = QCheckBox(self.plot_config)
        self.hp2.setObjectName(u"hp2")
        self.hp2.setChecked(True)

        self.verticalLayout_8.addWidget(self.hp2)

        self.hp3 = QCheckBox(self.plot_config)
        self.hp3.setObjectName(u"hp3")
        self.hp3.setChecked(True)

        self.verticalLayout_8.addWidget(self.hp3)

        self.hp4 = QCheckBox(self.plot_config)
        self.hp4.setObjectName(u"hp4")

        self.verticalLayout_8.addWidget(self.hp4)

        self.hp5 = QCheckBox(self.plot_config)
        self.hp5.setObjectName(u"hp5")

        self.verticalLayout_8.addWidget(self.hp5)

        self.hp6 = QCheckBox(self.plot_config)
        self.hp6.setObjectName(u"hp6")

        self.verticalLayout_8.addWidget(self.hp6)

        self.hp7 = QCheckBox(self.plot_config)
        self.hp7.setObjectName(u"hp7")

        self.verticalLayout_8.addWidget(self.hp7)

        self.hp8 = QCheckBox(self.plot_config)
        self.hp8.setObjectName(u"hp8")

        self.verticalLayout_8.addWidget(self.hp8)

        self.hp9 = QCheckBox(self.plot_config)
        self.hp9.setObjectName(u"hp9")

        self.verticalLayout_8.addWidget(self.hp9)

        self.hp10 = QCheckBox(self.plot_config)
        self.hp10.setObjectName(u"hp10")

        self.verticalLayout_8.addWidget(self.hp10)

        self.hp11 = QCheckBox(self.plot_config)
        self.hp11.setObjectName(u"hp11")

        self.verticalLayout_8.addWidget(self.hp11)


        self.horizontalLayout_19.addLayout(self.verticalLayout_8)

        self.verticalLayout_9 = QVBoxLayout()
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.ap1 = QCheckBox(self.plot_config)
        self.ap1.setObjectName(u"ap1")
        self.ap1.setChecked(True)

        self.verticalLayout_9.addWidget(self.ap1)

        self.ap2 = QCheckBox(self.plot_config)
        self.ap2.setObjectName(u"ap2")
        self.ap2.setChecked(True)

        self.verticalLayout_9.addWidget(self.ap2)

        self.ap3 = QCheckBox(self.plot_config)
        self.ap3.setObjectName(u"ap3")
        self.ap3.setChecked(True)

        self.verticalLayout_9.addWidget(self.ap3)

        self.ap4 = QCheckBox(self.plot_config)
        self.ap4.setObjectName(u"ap4")

        self.verticalLayout_9.addWidget(self.ap4)

        self.ap5 = QCheckBox(self.plot_config)
        self.ap5.setObjectName(u"ap5")

        self.verticalLayout_9.addWidget(self.ap5)

        self.ap6 = QCheckBox(self.plot_config)
        self.ap6.setObjectName(u"ap6")

        self.verticalLayout_9.addWidget(self.ap6)

        self.ap7 = QCheckBox(self.plot_config)
        self.ap7.setObjectName(u"ap7")

        self.verticalLayout_9.addWidget(self.ap7)

        self.ap8 = QCheckBox(self.plot_config)
        self.ap8.setObjectName(u"ap8")

        self.verticalLayout_9.addWidget(self.ap8)

        self.ap9 = QCheckBox(self.plot_config)
        self.ap9.setObjectName(u"ap9")

        self.verticalLayout_9.addWidget(self.ap9)

        self.ap10 = QCheckBox(self.plot_config)
        self.ap10.setObjectName(u"ap10")

        self.verticalLayout_9.addWidget(self.ap10)

        self.ap11 = QCheckBox(self.plot_config)
        self.ap11.setObjectName(u"ap11")

        self.verticalLayout_9.addWidget(self.ap11)


        self.horizontalLayout_19.addLayout(self.verticalLayout_9)


        self.verticalLayout_10.addLayout(self.horizontalLayout_19)


        self.verticalLayout_17.addLayout(self.verticalLayout_10)

        self.update_config = QPushButton(self.plot_config)
        self.update_config.setObjectName(u"update_config")

        self.verticalLayout_17.addWidget(self.update_config)

        self.verticalSpacer_4 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_17.addItem(self.verticalSpacer_4)


        self.horizontalLayout_31.addLayout(self.verticalLayout_17)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_31.addItem(self.horizontalSpacer_3)

        self.tabWidget.addTab(self.plot_config, "")
        self.view = QWidget()
        self.view.setObjectName(u"view")
        self.verticalLayout_2 = QVBoxLayout(self.view)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.figure = Figure()

        self.canvas = FigureCanvasQTAgg(self.figure)
        
        self.horizontalLayout_2.insertWidget(0,self.canvas)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.btn_default = QPushButton(self.view)
        self.btn_default.setObjectName(u"btn_default")

        self.verticalLayout.addWidget(self.btn_default)

        self.btn_rectangle = QPushButton(self.view)
        self.btn_rectangle.setObjectName(u"btn_rectangle")

        self.verticalLayout.addWidget(self.btn_rectangle)

        self.btn_convex = QPushButton(self.view)
        self.btn_convex.setObjectName(u"btn_convex")

        self.verticalLayout.addWidget(self.btn_convex)

        self.btn_voronoi = QPushButton(self.view)
        self.btn_voronoi.setObjectName(u"btn_voronoi")

        self.verticalLayout.addWidget(self.btn_voronoi)

        self.btn_dist = QPushButton(self.view)
        self.btn_dist.setObjectName(u"btn_dist")

        self.verticalLayout.addWidget(self.btn_dist)

        self.btn_dot = QPushButton(self.view)
        self.btn_dot.setObjectName(u"btn_dot")

        self.verticalLayout.addWidget(self.btn_dot)

        self.btn_team_centroid = QPushButton(self.view)
        self.btn_team_centroid.setObjectName(u"btn_team_centroid")

        self.verticalLayout.addWidget(self.btn_team_centroid)

        self.btn_centroid = QPushButton(self.view)
        self.btn_centroid.setObjectName(u"btn_centroid")

        self.verticalLayout.addWidget(self.btn_centroid)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)


        self.horizontalLayout_2.addLayout(self.verticalLayout)


        self.verticalLayout_2.addLayout(self.horizontalLayout_2)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label = QLabel(self.view)
        self.label.setObjectName(u"label")

        self.horizontalLayout.addWidget(self.label)

        self.FrameInput = QLineEdit(self.view)
        self.FrameInput.setObjectName(u"FrameInput")

        self.horizontalLayout.addWidget(self.FrameInput)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer_2)

        self.back15s = QPushButton(self.view)
        self.back15s.setObjectName(u"back15s")

        self.horizontalLayout.addWidget(self.back15s)

        self.Play = QPushButton(self.view)
        self.Play.setObjectName(u"Play")

        self.horizontalLayout.addWidget(self.Play)

        self.forward15s = QPushButton(self.view)
        self.forward15s.setObjectName(u"forward15s")

        self.horizontalLayout.addWidget(self.forward15s)

        self.label_2 = QLabel(self.view)
        self.label_2.setObjectName(u"label_2")

        self.horizontalLayout.addWidget(self.label_2)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.TimeInput = QLineEdit(self.view)
        self.TimeInput.setObjectName(u"TimeInput")

        self.horizontalLayout.addWidget(self.TimeInput)


        self.verticalLayout_2.addLayout(self.horizontalLayout)

        self.horizontalSlider = QSlider(self.view)
        self.horizontalSlider.setObjectName(u"horizontalSlider")
        self.horizontalSlider.setOrientation(Qt.Horizontal)

        self.verticalLayout_2.addWidget(self.horizontalSlider)

        self.horizontalLayout_30 = QHBoxLayout()
        self.horizontalLayout_30.setObjectName(u"horizontalLayout_30")
        self.label_45 = QLabel(self.view)
        self.label_45.setObjectName(u"label_45")

        self.horizontalLayout_30.addWidget(self.label_45)

        self.start_frame = QLineEdit(self.view)
        self.start_frame.setObjectName(u"start_frame")
        self.start_frame.setMaximumSize(QSize(60, 16777215))

        self.horizontalLayout_30.addWidget(self.start_frame)

        self.btn_asf = QPushButton(self.view)
        self.btn_asf.setObjectName(u"btn_asf")

        self.horizontalLayout_30.addWidget(self.btn_asf)
        
        self.check_home_event = QCheckBox(self.view)
        self.check_home_event.setObjectName(u"check_home_event")

        self.horizontalLayout_30.addWidget(self.check_home_event)

        self.horizontalSpacer_7 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_30.addItem(self.horizontalSpacer_7)

        self.event_commit_name = QLineEdit(self.view)
        self.event_commit_name.setObjectName(u"event_commit_name")
        self.event_commit_name.setMinimumSize(QSize(80, 0))

        self.horizontalLayout_30.addWidget(self.event_commit_name)

        self.horizontalSpacer_6 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_30.addItem(self.horizontalSpacer_6)

        self.label_46 = QLabel(self.view)
        self.label_46.setObjectName(u"label_46")

        self.horizontalLayout_30.addWidget(self.label_46)

        self.end_frame = QLineEdit(self.view)
        self.end_frame.setObjectName(u"end_frame")
        self.end_frame.setMaximumSize(QSize(50, 16777215))

        self.horizontalLayout_30.addWidget(self.end_frame)

        self.btn_aef = QPushButton(self.view)
        self.btn_aef.setObjectName(u"btn_aef")

        self.horizontalLayout_30.addWidget(self.btn_aef)

        self.horizontalSpacer_8 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_30.addItem(self.horizontalSpacer_8)

        self.btn_tab_record = QPushButton(self.view)
        self.btn_tab_record.setObjectName(u"btn_tab_record")

        self.horizontalLayout_30.addWidget(self.btn_tab_record)


        self.verticalLayout_2.addLayout(self.horizontalLayout_30)

        self.tabWidget.addTab(self.view, "")
        self.record = QWidget()
        self.record.setObjectName(u"record")
        self.gridLayout_3 = QGridLayout(self.record)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.horizontalSpacer_4 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.gridLayout_3.addItem(self.horizontalSpacer_4, 0, 1, 1, 1)

        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.label_5 = QLabel(self.record)
        self.label_5.setObjectName(u"label_5")
        font3 = QFont()
        font3.setPointSize(11)
        font3.setBold(True)
        self.label_5.setFont(font3)

        self.verticalLayout_3.addWidget(self.label_5)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.label_6 = QLabel(self.record)
        self.label_6.setObjectName(u"label_6")

        self.horizontalLayout_3.addWidget(self.label_6)

        self.first_frame = QSpinBox(self.record)
        self.first_frame.setObjectName(u"first_frame")
        self.first_frame.setMaximum(100000000)

        self.horizontalLayout_3.addWidget(self.first_frame)

        self.label_7 = QLabel(self.record)
        self.label_7.setObjectName(u"label_7")

        self.horizontalLayout_3.addWidget(self.label_7)

        self.last_frame = QSpinBox(self.record)
        self.last_frame.setObjectName(u"last_frame")
        self.last_frame.setMaximum(100000000)
        self.last_frame.setValue(1000)

        self.horizontalLayout_3.addWidget(self.last_frame)


        self.verticalLayout_3.addLayout(self.horizontalLayout_3)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.label_8 = QLabel(self.record)
        self.label_8.setObjectName(u"label_8")

        self.horizontalLayout_4.addWidget(self.label_8)

        self.pb_speed = QDoubleSpinBox(self.record)
        self.pb_speed.setObjectName(u"pb_speed")
        self.pb_speed.setMinimum(-100.000000000000000)
        self.pb_speed.setMaximum(100.000000000000000)
        self.pb_speed.setValue(1.000000000000000)

        self.horizontalLayout_4.addWidget(self.pb_speed)


        self.verticalLayout_3.addLayout(self.horizontalLayout_4)

        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.label_10 = QLabel(self.record)
        self.label_10.setObjectName(u"label_10")

        self.horizontalLayout_6.addWidget(self.label_10)

        self.pb_speed_2 = QSpinBox(self.record)
        self.pb_speed_2.setObjectName(u"pb_speed_2")
        self.pb_speed_2.setMinimum(120)
        self.pb_speed_2.setMaximum(960)
        self.pb_speed_2.setValue(240)

        self.horizontalLayout_6.addWidget(self.pb_speed_2)


        self.verticalLayout_3.addLayout(self.horizontalLayout_6)

        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.label_9 = QLabel(self.record)
        self.label_9.setObjectName(u"label_9")

        self.horizontalLayout_5.addWidget(self.label_9)

        self.recording_name = QLineEdit(self.record)
        self.recording_name.setObjectName(u"recording_name")

        self.horizontalLayout_5.addWidget(self.recording_name)


        self.verticalLayout_3.addLayout(self.horizontalLayout_5)

        self.button_record = QPushButton(self.record)
        self.button_record.setObjectName(u"button_record")

        self.verticalLayout_3.addWidget(self.button_record)

        self.label_11 = QLabel(self.record)
        self.label_11.setObjectName(u"label_11")

        self.verticalLayout_3.addWidget(self.label_11)


        self.gridLayout_3.addLayout(self.verticalLayout_3, 0, 0, 1, 1)

        self.verticalSpacer_3 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.gridLayout_3.addItem(self.verticalSpacer_3, 1, 0, 1, 1)

        self.tabWidget.addTab(self.record, "")

        self.gridLayout.addWidget(self.tabWidget, 1, 0, 1, 1)

        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        
        #User defined
        
        self.check_load_all.toggled.connect(self.update_frames)
        
        
        cwd=os.getcwd()
        game_id = self.game_id.value()

        data_loc=cwd+"\\Tracking Data\\"+str(game_id)+".jsonl\\"+str(game_id)+".jsonl"

        with open(data_loc, "r", encoding="utf-8") as f:
            self.n_frames = sum(1 for _ in f)
        
        self.frames_inp.setMaximum(self.n_frames)
        

        
        self.event_load_name.setEnabled(False)
        
        self.btn_tab_record.clicked.connect(self.rec_tab_data)
        self.btn_asf.clicked.connect(self.assign_start_frame)
        self.btn_aef.clicked.connect(self.assign_end_frame)
        
        self.check_load_event.toggled.connect(self.toggle_inputs)
        
        # Space = Play/Pause
        self.shortcut_play = QShortcut(QKeySequence(Qt.Key_Space), MainWindow)
        self.shortcut_play.activated.connect(self.toggle_play)
        
        # Left Arrow = Back 15s
        self.shortcut_back = QShortcut(QKeySequence(Qt.Key_Left), MainWindow)
        self.shortcut_back.activated.connect(self.jump_back_15s)
        
        # Right Arrow = Forward 15s
        self.shortcut_forward = QShortcut(QKeySequence(Qt.Key_Right), MainWindow)
        self.shortcut_forward.activated.connect(self.jump_forward_15s)
        
        self.shortcut_next = QShortcut(QKeySequence(Qt.Key_Up), MainWindow)
        self.shortcut_next.activated.connect(
            lambda: self.horizontalSlider.setValue(
                min(self.current_frame + 1,
                    self.horizontalSlider.maximum())
            )
        )
        
        self.shortcut_prev = QShortcut(QKeySequence(Qt.Key_Down), MainWindow)
        self.shortcut_prev.activated.connect(
            lambda: self.horizontalSlider.setValue(
                max(self.current_frame - 1, 0)
            )
        )
        
        for button in [
            self.btn_rectangle,
            self.btn_convex,
            self.btn_voronoi,
            self.btn_dist,
            self.btn_dot,
            self.btn_team_centroid,
            self.btn_centroid
        ]:
            button.setFixedWidth(150)
        
        self.timer = None
        self.back15s.clicked.connect(self.jump_back_15s)
        self.forward15s.clicked.connect(self.jump_forward_15s)
        self.horizontalSlider.valueChanged.connect(self.slider_changed)

        # Connect button click
        self.button_record.clicked.connect(self.record_data)

        # Connect button click
        self.update_config.clicked.connect(self.process_data)
                
        # Connect button click
        self.btn_load_data.clicked.connect(self.load_data)
        
        # Connect button click
        self.Play.clicked.connect(self.toggle_play)
        # Connect button click
        self.btn_default.clicked.connect(
            lambda: self.set_plot_type("bool_default")
        )
        
        self.btn_rectangle.clicked.connect(
            lambda: self.set_plot_type("bool_rectangle")
        )
        
        self.btn_convex.clicked.connect(
            lambda: self.set_plot_type("bool_convex")
        )
        
        self.btn_voronoi.clicked.connect(
            lambda: self.set_plot_type("bool_voronoi")
        )
        
        self.btn_dist.clicked.connect(
            lambda: self.set_plot_type("bool_dist")
        )
        
        self.btn_dot.clicked.connect(
            lambda: self.set_plot_type("bool_dot")
        )
        
        self.btn_team_centroid.clicked.connect(
            lambda: self.set_plot_type("bool_team_centroid")
        )
        
        self.btn_centroid.clicked.connect(
            lambda: self.set_plot_type("bool_centroids")
        )
        QMetaObject.connectSlotsByName(MainWindow)
        
        self.tabWidget.setCurrentIndex(0)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label_48.setText(QCoreApplication.translate("MainWindow", u"Football Visualiser", None))
        self.label_49.setText(QCoreApplication.translate("MainWindow", u"by Joshua Montgomery, version 1.0", None))
        self.label_50.setText(QCoreApplication.translate("MainWindow", u"Loading Event or Raw Data", None))
        self.label_51.setText(QCoreApplication.translate("MainWindow", u"Events can be saved in the viewer tab. These events can be reloaded by checking the load event box and specifying the filename", None))
        self.check_load_event.setText(QCoreApplication.translate("MainWindow", u"Load Event", None))
        self.event_load_name.setText(QCoreApplication.translate("MainWindow", u"Event Name", None))
        self.label_52.setText(QCoreApplication.translate("MainWindow", u"Loading Configuration", None))
        self.label_23.setText(QCoreApplication.translate("MainWindow", u"Game ID", None))
        self.check_load_all.setText(QCoreApplication.translate("MainWindow", u"Load All Frames", None))
        self.label_24.setText(QCoreApplication.translate("MainWindow", u"Load Frames", None))
        self.check_auto_process.setText(QCoreApplication.translate("MainWindow", u"Process Data Immediately", None))
        self.btn_load_data.setText(QCoreApplication.translate("MainWindow", u"Load Data", None))
        self.label_13.setText(QCoreApplication.translate("MainWindow", u"Team Setup", None))
        self.label_14.setText(QCoreApplication.translate("MainWindow", u"Proper centroid plotting requires that each team position is specfifed to a rank. Note that if there are only three ranks (for example if playing 3-4-3), the last rank must be the empty rank", None))
        self.label_15.setText(QCoreApplication.translate("MainWindow", u"Home R1", None))
        self.home_rank1_inp.setText(QCoreApplication.translate("MainWindow", u"['RB','RCB','LCB','LB']", None))
        self.label_16.setText(QCoreApplication.translate("MainWindow", u"Home R2", None))
        self.home_rank2_inp.setText(QCoreApplication.translate("MainWindow", u"['AM','CM','DM']", None))
        self.label_17.setText(QCoreApplication.translate("MainWindow", u"Home R3", None))
        self.home_rank3_inp.setText(QCoreApplication.translate("MainWindow", u"['RW','CF','LW']", None))
        self.label_18.setText(QCoreApplication.translate("MainWindow", u"Home R4", None))
        self.home_rank4_inp.setText(QCoreApplication.translate("MainWindow", u"[]", None))
        self.label_20.setText(QCoreApplication.translate("MainWindow", u"Away R1", None))
        self.away_rank1_inp.setText(QCoreApplication.translate("MainWindow", u"['RB','RCB','LCB','LB']", None))
        self.label_22.setText(QCoreApplication.translate("MainWindow", u"Away R2", None))
        self.away_rank2_inp.setText(QCoreApplication.translate("MainWindow", u"['AM','CM','DM']", None))
        self.label_19.setText(QCoreApplication.translate("MainWindow", u"Away R3", None))
        self.away_rank3_inp.setText(QCoreApplication.translate("MainWindow", u"['RW','CF','LW']", None))
        self.label_21.setText(QCoreApplication.translate("MainWindow", u"Away R4", None))
        self.away_rank4_inp.setText(QCoreApplication.translate("MainWindow", u"[]", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.load), QCoreApplication.translate("MainWindow", u"Load", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"General", None))
        self.check_player_name.setText(QCoreApplication.translate("MainWindow", u"Plot Player Names", None))
        self.check_player_surname_only.setText(QCoreApplication.translate("MainWindow", u"Only Player Surnames", None))
        self.check_ball.setText(QCoreApplication.translate("MainWindow", u"Plot the Ball", None))
        self.check_z_ball.setText(QCoreApplication.translate("MainWindow", u"Plot Ball in Z", None))
        self.check_axis_labels.setText(QCoreApplication.translate("MainWindow", u"Axis Labels", None))
        self.check_flip_ends.setText(QCoreApplication.translate("MainWindow", u"Flip Ends", None))
        self.check_generic_colours.setText(QCoreApplication.translate("MainWindow", u"Generic Colours", None))
        self.check_pitch_colour.setText(QCoreApplication.translate("MainWindow", u"Colourful Pitch", None))
        self.label_47.setText(QCoreApplication.translate("MainWindow", u"Frame Skip", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"Plot Overlay", None))
        self.check_cum_dist.setText(QCoreApplication.translate("MainWindow", u"Plot Cumulative Distance", None))
        self.check_speed.setText(QCoreApplication.translate("MainWindow", u"Plot Speed ", None))
        self.label_12.setText(QCoreApplication.translate("MainWindow", u"Centroid Config", None))
        self.check_centroids_connector.setText(QCoreApplication.translate("MainWindow", u"Plot Connector", None))
        self.check_centroids_home.setText(QCoreApplication.translate("MainWindow", u"Plot Home Centroids", None))
        self.check_centroids_away.setText(QCoreApplication.translate("MainWindow", u"Plot Away Centroids", None))
        self.label_34.setText(QCoreApplication.translate("MainWindow", u"Centroid Scale", None))
        self.label_35.setText(QCoreApplication.translate("MainWindow", u"Voronoi ", None))
        self.check_voronoi_colour.setText(QCoreApplication.translate("MainWindow", u"Colour", None))
        self.check_highlight_players.setText(QCoreApplication.translate("MainWindow", u"Highlight Players", None))
        self.label_36.setText(QCoreApplication.translate("MainWindow", u"Display", None))
        self.label_37.setText(QCoreApplication.translate("MainWindow", u"Font Size", None))
        self.label_38.setText(QCoreApplication.translate("MainWindow", u"Scatter Size", None))
        self.label_39.setText(QCoreApplication.translate("MainWindow", u"Min Ball Scale", None))
        self.label_40.setText(QCoreApplication.translate("MainWindow", u"Max Ball Scale", None))
        self.label_30.setText(QCoreApplication.translate("MainWindow", u"Player Selector - Distance", None))
        self.label_31.setText(QCoreApplication.translate("MainWindow", u"Only one player can be selected", None))
        self.label_32.setText(QCoreApplication.translate("MainWindow", u"Player", None))
        self.label_33.setText(QCoreApplication.translate("MainWindow", u"Line Width", None))
        self.check_dist_home.setText(QCoreApplication.translate("MainWindow", u"Home Player", None))
        self.check_dist_away.setText(QCoreApplication.translate("MainWindow", u"Away Player", None))
        self.check_dist_comp_home.setText(QCoreApplication.translate("MainWindow", u"Compare to Home Team", None))
        self.check_dist_comp_away.setText(QCoreApplication.translate("MainWindow", u"Compare to Away Team", None))
        self.label_25.setText(QCoreApplication.translate("MainWindow", u"Dot Config", None))
        self.check_dots_home.setText(QCoreApplication.translate("MainWindow", u"Plot Home Dots", None))
        self.check_dots_away.setText(QCoreApplication.translate("MainWindow", u"Plot Away Dots", None))
        self.check_dots_per_second.setText(QCoreApplication.translate("MainWindow", u"Dots Per Second", None))
        self.check_dots_per_pos.setText(QCoreApplication.translate("MainWindow", u"Dots Per Position", None))
        self.label_26.setText(QCoreApplication.translate("MainWindow", u"Dots Per Second", None))
        self.label_27.setText(QCoreApplication.translate("MainWindow", u"Dots Per Position", None))
        self.label_41.setText(QCoreApplication.translate("MainWindow", u"Colours", None))
        self.label_42.setText(QCoreApplication.translate("MainWindow", u"Pitch Colour", None))
        self.pitch_colour.setText(QCoreApplication.translate("MainWindow", u"'#017d22'", None))
        self.label_43.setText(QCoreApplication.translate("MainWindow", u"Contrast Colour", None))
        self.contrast_colours.setMarkdown(QCoreApplication.translate("MainWindow", u"['#0040ff','#fffefc','#fa0000','#0d0d0d']\n"
"\n"
"", None))
        self.label_44.setText(QCoreApplication.translate("MainWindow", u"Dot Colours", None))
        self.dot_colours.setMarkdown(QCoreApplication.translate("MainWindow", u"['#9e0142','#d53e4f','#f46d43','#fdae61','#fee08b',\n"
"\n"
"'#e6f598','#abdda4','#66c2a5','#3288bd','#5e4fa2']\n"
"\n"
"", None))
        self.label_28.setText(QCoreApplication.translate("MainWindow", u"Player Selector", None))
        self.label_29.setText(QCoreApplication.translate("MainWindow", u"This is for the voronoi and dot plots", None))
        self.hp1.setText(QCoreApplication.translate("MainWindow", u"Home Player 1", None))
        self.hp2.setText(QCoreApplication.translate("MainWindow", u"Home Player 2", None))
        self.hp3.setText(QCoreApplication.translate("MainWindow", u"Home Player 3", None))
        self.hp4.setText(QCoreApplication.translate("MainWindow", u"Home Player 4", None))
        self.hp5.setText(QCoreApplication.translate("MainWindow", u"Home Player 5", None))
        self.hp6.setText(QCoreApplication.translate("MainWindow", u"Home Player 6", None))
        self.hp7.setText(QCoreApplication.translate("MainWindow", u"Home Player 7", None))
        self.hp8.setText(QCoreApplication.translate("MainWindow", u"Home Player 8", None))
        self.hp9.setText(QCoreApplication.translate("MainWindow", u"Home Player 9", None))
        self.hp10.setText(QCoreApplication.translate("MainWindow", u"Home Player 10", None))
        self.hp11.setText(QCoreApplication.translate("MainWindow", u"Home Player 11", None))
        self.ap1.setText(QCoreApplication.translate("MainWindow", u"Away Player 1", None))
        self.ap2.setText(QCoreApplication.translate("MainWindow", u"Away Player 2", None))
        self.ap3.setText(QCoreApplication.translate("MainWindow", u"Away Player 3", None))
        self.ap4.setText(QCoreApplication.translate("MainWindow", u"Away Player 4", None))
        self.ap5.setText(QCoreApplication.translate("MainWindow", u"Away Player 5", None))
        self.ap6.setText(QCoreApplication.translate("MainWindow", u"Away Player 6", None))
        self.ap7.setText(QCoreApplication.translate("MainWindow", u"Away Player 7", None))
        self.ap8.setText(QCoreApplication.translate("MainWindow", u"Away Player 8", None))
        self.ap9.setText(QCoreApplication.translate("MainWindow", u"Away Player 9", None))
        self.ap10.setText(QCoreApplication.translate("MainWindow", u"Away Player 10", None))
        self.ap11.setText(QCoreApplication.translate("MainWindow", u"Away Player 11", None))
        self.update_config.setText(QCoreApplication.translate("MainWindow", u"Update Config", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.plot_config), QCoreApplication.translate("MainWindow", u"Plot Config", None))
        self.btn_default.setText(QCoreApplication.translate("MainWindow", u"Default", None))
        self.btn_rectangle.setText(QCoreApplication.translate("MainWindow", u"Rectangle", None))
        self.btn_convex.setText(QCoreApplication.translate("MainWindow", u"Convex Hull", None))
        self.btn_voronoi.setText(QCoreApplication.translate("MainWindow", u"Voronoi", None))
        self.btn_dist.setText(QCoreApplication.translate("MainWindow", u"Distance", None))
        self.btn_dot.setText(QCoreApplication.translate("MainWindow", u"Dot", None))
        self.btn_team_centroid.setText(QCoreApplication.translate("MainWindow", u"Team Centroid", None))
        self.btn_centroid.setText(QCoreApplication.translate("MainWindow", u"Position Centroids", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Frame:", None))
        self.back15s.setText(QCoreApplication.translate("MainWindow", u"Go Back 15s", None))
        self.Play.setText(QCoreApplication.translate("MainWindow", u"Play", None))
        self.forward15s.setText(QCoreApplication.translate("MainWindow", u"Go Forward 15s", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Time (s):", None))
        self.label_45.setText(QCoreApplication.translate("MainWindow", u"Start Frame:", None))
        self.btn_asf.setText(QCoreApplication.translate("MainWindow", u"Assign Start Frame", None))
        self.event_commit_name.setText(QCoreApplication.translate("MainWindow", u"Event Name", None))
        self.label_46.setText(QCoreApplication.translate("MainWindow", u"End Frame:", None))
        self.btn_aef.setText(QCoreApplication.translate("MainWindow", u"Assign End Frame", None))
        self.check_home_event.setText(QCoreApplication.translate("MainWindow", u"Home Team Event", None))
        self.btn_tab_record.setText(QCoreApplication.translate("MainWindow", u"Commit", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.view), QCoreApplication.translate("MainWindow", u"View", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"Recording Configuration", None))
        self.label_6.setText(QCoreApplication.translate("MainWindow", u"First Frame:", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"Last Frame:", None))
        self.label_8.setText(QCoreApplication.translate("MainWindow", u"Playback Speed", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"Recording Quality", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"Recording Filename", None))
        self.recording_name.setText(QCoreApplication.translate("MainWindow", u"Match_Clip", None))
        self.button_record.setText(QCoreApplication.translate("MainWindow", u"Record", None))
        self.label_11.setText(QCoreApplication.translate("MainWindow", u"The last plot type selected on the 'View' tab will set the type", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.record), QCoreApplication.translate("MainWindow", u"Record", None))
    # retranslateUi

if __name__ == "__main__":

    app = QApplication.instance()

    if app is None:
        app = QApplication(sys.argv)

    MainWindow = QMainWindow()

    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)

    MainWindow.show()

    sys.exit(app.exec())